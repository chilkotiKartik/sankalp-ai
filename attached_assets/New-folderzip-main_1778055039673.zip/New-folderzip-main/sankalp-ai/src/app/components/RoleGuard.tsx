"use client";

import React from "react";
import { useAuth, User } from "./AuthProvider";

interface RoleGuardProps {
  allowedRoles: User["role"][];
  children: React.ReactNode;
}

export default function RoleGuard({ allowedRoles, children }: RoleGuardProps) {
  const { user, isAuthenticated, authLoading } = useAuth();

  if (authLoading) {
    return (
      <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{
          width: "40px", height: "40px", borderRadius: "50%",
          border: "3px solid rgba(26,46,42,0.1)",
          borderTopColor: "#FF6B2B",
          animation: "spin 0.7s linear infinite",
        }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return (
      <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "24px" }}>
        <div style={{
          textAlign: "center", maxWidth: "400px",
          background: "white", borderRadius: "20px",
          border: "1.5px solid rgba(26,46,42,0.07)",
          padding: "48px 36px",
        }}>
          <div style={{ fontSize: "32px", marginBottom: "16px" }}>🔒</div>
          <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: "26px", color: "#1A2E2A", marginBottom: "8px" }}>
            Sign in required
          </h2>
          <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "14px", color: "rgba(26,46,42,0.5)", lineHeight: 1.6 }}>
            Loading your session...
          </p>
        </div>
      </div>
    );
  }

  if (!allowedRoles.includes(user.role)) {
    return (
      <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "24px" }}>
        <div style={{
          textAlign: "center", maxWidth: "420px",
          background: "white", borderRadius: "20px",
          border: "1.5px solid rgba(26,46,42,0.07)",
          padding: "48px 36px",
        }}>
          <div style={{ fontSize: "32px", marginBottom: "16px" }}>🚫</div>
          <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: "26px", color: "#1A2E2A", marginBottom: "8px" }}>
            Access Denied
          </h2>
          <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "14px", color: "rgba(26,46,42,0.5)", marginBottom: "8px", lineHeight: 1.6 }}>
            You don&apos;t have permission to view this page.
          </p>
          <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "12px", color: "rgba(26,46,42,0.35)" }}>
            Signed in as <strong>{user.name}</strong> &middot; <strong style={{ color: "#FF6B2B", textTransform: "capitalize" }}>{user.role.replace("_", " ")}</strong>
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
