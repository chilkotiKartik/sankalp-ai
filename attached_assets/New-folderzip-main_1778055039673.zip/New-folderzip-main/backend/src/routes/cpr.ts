import { Router, Request, Response } from "express";
import { civicStore } from "../db/extensions";
import { requireAuth } from "../middleware/auth";

const router = Router();

router.get("/api/cpr/patrols", requireAuth, (req: Request, res: Response) => {
  const district = req.query.district as string|undefined;
  res.json(civicStore.getPatrolVans(district));
});

router.put("/api/cpr/patrols/:id/location", (req: Request, res: Response) => {
  const { lat, lng } = req.body as { lat:number; lng:number };
  if (!lat||!lng) { res.status(400).json({ error:"lat and lng required" }); return; }
  const van = civicStore.updatePatrolLocation(req.params.id, { lat:parseFloat(String(lat)), lng:parseFloat(String(lng)) });
  if (!van) { res.status(404).json({ error:"Van not found" }); return; }
  res.json(van);
});

router.post("/api/cpr/patrols/:id/dispatch", requireAuth, (req: Request, res: Response) => {
  const { incidentId } = req.body as { incidentId:string };
  const van = civicStore.dispatchPatrol(req.params.id, incidentId);
  if (!van) { res.status(404).json({ error:"Van not found" }); return; }
  res.json(van);
});

router.get("/api/cpr/incidents", requireAuth, (req: Request, res: Response) => {
  const district = req.query.district as string|undefined;
  res.json(civicStore.getSafetyIncidents(district));
});

router.post("/api/cpr/incidents", requireAuth, (req: Request, res: Response) => {
  const { lat, lng, location, district, citizenName, sosId } = req.body as {
    lat:number; lng:number; location:string; district:string; citizenName:string; sosId?:string;
  };
  if (!lat||!lng||!location||!district||!citizenName) {
    res.status(400).json({ error:"lat, lng, location, district, citizenName required" }); return;
  }
  const inc = civicStore.createSafetyIncident(
    { lat:parseFloat(String(lat)), lng:parseFloat(String(lng)) },
    location, district, citizenName, sosId||`sos-${Date.now()}`
  );
  res.status(201).json(inc);
});

router.put("/api/cpr/incidents/:id/update", requireAuth, (req: Request, res: Response) => {
  const { status, message } = req.body as { status:string; message:string };
  const user = req.user;
  const inc = civicStore.updateIncidentStatus(
    req.params.id, status as Parameters<typeof civicStore.updateIncidentStatus>[1],
    message || `Status updated to ${status}`,
    user?.phone || "Officer"
  );
  if (!inc) { res.status(404).json({ error:"Not found" }); return; }
  res.json(inc);
});

router.get("/api/cpr/stream", (req: Request, res: Response) => {
  res.setHeader("Content-Type","text/event-stream");
  res.setHeader("Cache-Control","no-cache");
  res.setHeader("Connection","keep-alive");
  res.setHeader("Access-Control-Allow-Origin","*");
  res.flushHeaders();
  const hb = setInterval(() => res.write(`data: ${JSON.stringify({type:"ping"})}\n\n`), 20000);
  const listener = (ev: unknown) => {
    const e = ev as { type:string };
    const relevant = ["safety_incident_new","incident_updated","incident_escalated","patrol_locations_batch","patrol_dispatched"];
    if (relevant.includes(e.type)) res.write(`data: ${JSON.stringify(ev)}\n\n`);
  };
  civicStore.addListener(listener);
  req.on("close", () => { clearInterval(hb); civicStore.removeListener(listener); });
});

router.get("/api/cpr/stats", requireAuth, (_req, res) => {
  const all = civicStore.safetyIncidents;
  const patrols = civicStore.patrolVans;
  res.json({
    totalIncidents: all.length,
    activeIncidents: all.filter(i=>i.status!=="safe"&&i.status!=="closed").length,
    resolvedToday: all.filter(i=>(i.status==="safe"||i.status==="closed")&&i.safeConfirmedAt&&Date.now()-new Date(i.safeConfirmedAt).getTime()<86400000).length,
    patrolsOnDuty: patrols.filter(v=>v.status!=="off_duty").length,
    patrolsActive: patrols.filter(v=>v.status==="active_patrol").length,
    patrolsResponding: patrols.filter(v=>v.status==="responding").length,
    womenSafetyUnits: patrols.filter(v=>v.isWomenSafetyUnit).length,
  });
});

export default router;
