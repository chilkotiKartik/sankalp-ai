import { Router, Request, Response } from "express";
import { requireAuth } from "../middleware/auth";
import { civicStore, DEPARTMENTS, getDeptForCategory } from "../db/extensions";
import { store } from "../db/inMemory";

const router = Router();

// ── RTI ───────────────────────────────────────────────────────────────────────
router.get("/api/rti", requireAuth, (req: Request, res: Response) => {
  res.json(civicStore.getRTIs(req.user?.userId));
});

router.post("/api/rti", requireAuth, (req: Request, res: Response) => {
  const user = req.user!;
  const { title, questionText, targetDepartment, aiDraftUsed, district } = req.body as {
    title?:string; questionText?:string; targetDepartment?:string; aiDraftUsed?:boolean; district?:string;
  };
  if (!title||!questionText||!targetDepartment) { res.status(400).json({ error:"title, questionText, targetDepartment required" }); return; }
  const rti = civicStore.createRTI({
    userId:user.userId, userName:user.phone, title, questionText,
    targetDepartment, aiDraftUsed:!!aiDraftUsed, district:district||"Dehradun",
  });
  res.status(201).json(rti);
});

router.post("/api/rti/:id/submit", requireAuth, (req: Request, res: Response) => {
  const rti = civicStore.submitRTI(req.params.id);
  if (!rti) { res.status(404).json({ error:"Not found" }); return; }
  res.json(rti);
});

router.post("/api/rti/:id/respond", requireAuth, (req: Request, res: Response) => {
  const { responseText } = req.body as { responseText?:string };
  if (!responseText) { res.status(400).json({ error:"responseText required" }); return; }
  const rti = civicStore.respondRTI(req.params.id, responseText, req.user?.phone||"Officer");
  if (!rti) { res.status(404).json({ error:"Not found" }); return; }
  res.json(rti);
});

router.post("/api/rti/ai-draft", requireAuth, async (req: Request, res: Response) => {
  const { topic, targetDepartment, district } = req.body as { topic?:string; targetDepartment?:string; district?:string };
  const dept = targetDepartment || "PWD";
  const dist = district || "Dehradun";
  const topic_ = topic || "civic issue";
  const draft = `Under the Right to Information Act, 2005, I hereby request the following information regarding ${topic_} from ${dept}, Uttarakhand (District: ${dist}):

1. Please provide all records, files, and documents pertaining to ${topic_} in ${dist} district for the last 6 months.
2. Details of the budget allocated and expenditure incurred for addressing ${topic_} in the current financial year.
3. Current status of any pending works or complaints related to ${topic_}.
4. Names and designations of officers responsible for handling ${topic_} in ${dist}.

The information requested is sought under Section 6(1) of the RTI Act, 2005. Please provide a reply within 30 days as mandated by Section 7(1) of the Act.

Applicant Contact: [Your Phone/Email]
District: ${dist}, Uttarakhand`;
  res.json({ text: draft });
});

// ── POLLS ─────────────────────────────────────────────────────────────────────
router.get("/api/polls", requireAuth, (req: Request, res: Response) => {
  const district = req.query.district as string|undefined;
  res.json(civicStore.getPolls(district));
});

router.post("/api/polls", requireAuth, (req: Request, res: Response) => {
  const user = req.user!;
  const { question, options, endsAt, district, wardId } = req.body as {
    question?:string; options?:string[]; endsAt?:string; district?:string; wardId?:number;
  };
  if (!question||!options||!endsAt) { res.status(400).json({ error:"question, options, endsAt required" }); return; }
  const poll = civicStore.createPoll({ question, options, endsAt, district:district||"Dehradun", wardId, createdBy:user.userId });
  res.status(201).json(poll);
});

router.post("/api/polls/:id/vote", requireAuth, (req: Request, res: Response) => {
  const { option } = req.body as { option?:string };
  if (!option) { res.status(400).json({ error:"option required" }); return; }
  const poll = civicStore.votePoll(req.params.id, option, req.user!.userId);
  if (!poll) { res.status(400).json({ error:"Cannot vote: already voted, poll closed, or invalid option" }); return; }
  res.json(poll);
});

// ── PETITIONS ─────────────────────────────────────────────────────────────────
router.get("/api/petitions", requireAuth, (req: Request, res: Response) => {
  const district = req.query.district as string|undefined;
  res.json(civicStore.getPetitions(district));
});

router.post("/api/petitions", requireAuth, (req: Request, res: Response) => {
  const user = req.user!;
  const { title, description, threshold, ward, district } = req.body as {
    title?:string; description?:string; threshold?:number; ward?:string; district?:string;
  };
  if (!title||!description) { res.status(400).json({ error:"title and description required" }); return; }
  const p = civicStore.createPetition({
    title, description, createdBy:user.userId, creatorName:user.phone,
    district:district||"Dehradun", ward, threshold:threshold||500,
  });
  res.status(201).json(p);
});

router.post("/api/petitions/:id/sign", requireAuth, (req: Request, res: Response) => {
  const p = civicStore.signPetition(req.params.id, req.user!.userId);
  if (!p) { res.status(400).json({ error:"Already signed or petition not found" }); return; }
  res.json(p);
});

router.put("/api/petitions/:id/respond", requireAuth, (req: Request, res: Response) => {
  const { response } = req.body as { response?:string };
  if (!response) { res.status(400).json({ error:"response required" }); return; }
  const p = civicStore.respondPetition(req.params.id, response, req.user?.phone||"Officer");
  if (!p) { res.status(404).json({ error:"Not found" }); return; }
  res.json(p);
});

// ── MESSAGES ──────────────────────────────────────────────────────────────────
router.get("/api/complaints/:id/messages", requireAuth, (req: Request, res: Response) => {
  res.json(civicStore.getMessages(req.params.id));
});
router.post("/api/complaints/:id/messages", requireAuth, (req: Request, res: Response) => {
  const user = req.user!;
  const { content } = req.body as { content?:string };
  if (!content?.trim()) { res.status(400).json({ error:"content required" }); return; }
  const msg = civicStore.createMessage({
    complaintId:req.params.id, senderId:user.userId,
    senderName:user.phone, senderRole:user.role, content:content.trim(),
  });
  res.status(201).json(msg);
});
router.put("/api/complaints/:id/messages/read", requireAuth, (req: Request, res: Response) => {
  civicStore.markMessagesRead(req.params.id, req.user!.userId);
  res.json({ success:true });
});

// ── PUBLIC REPORTS ────────────────────────────────────────────────────────────
router.get("/api/public/department-report", (_req, res) => {
  const complaints = store.complaints.map(c => ({ category:c.category, status:c.status, priority:c.priority }));
  res.json(civicStore.getDepartmentReport(complaints));
});

router.get("/api/public/ward-health", (_req, res) => {
  const wards = store.wards.slice(0, 40).map(w => ({
    id: w.id,
    name: w.name,
    district: (w as unknown as { district?: string }).district || "Dehradun",
    healthScore: w.health_score,
    complaintCount: w.complaint_count,
    resolvedCount: w.resolved_count,
  }));
  res.json(wards);
});

router.get("/api/public/districts", (_req, res) => {
  const { UK_DISTRICTS } = require("../db/extensions");
  res.json(UK_DISTRICTS);
});

router.get("/api/public/stats", (_req, res) => {
  const stats = store.getAdminStats();
  const complaints = store.complaints;
  res.json({
    ...stats,
    totalCitizens: store.users.length,
    totalDistricts: 13,
    activePolls: civicStore.polls.filter(p=>p.isActive).length,
    activePetitions: civicStore.petitions.filter(p=>p.status==="active"||p.status==="escalated").length,
  });
});

// ── CIVIC SSE STREAM ──────────────────────────────────────────────────────────
router.get("/api/civic/stream", (req: Request, res: Response) => {
  res.setHeader("Content-Type","text/event-stream");
  res.setHeader("Cache-Control","no-cache");
  res.setHeader("Connection","keep-alive");
  res.setHeader("Access-Control-Allow-Origin","*");
  res.flushHeaders();
  const hb = setInterval(() => res.write(`data: ${JSON.stringify({type:"ping"})}\n\n`), 25000);
  const listener = (ev: unknown) => res.write(`data: ${JSON.stringify(ev)}\n\n`);
  civicStore.addListener(listener);
  req.on("close", () => { clearInterval(hb); civicStore.removeListener(listener); });
});

export default router;
