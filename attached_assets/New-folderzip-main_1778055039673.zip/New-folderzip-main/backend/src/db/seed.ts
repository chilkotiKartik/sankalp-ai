/**
 * Seed script for PostgreSQL (Uttarakhand data).
 * Usage: npm run seed
 * Requires DATABASE_URL env var.
 */

import dotenv from "dotenv";
dotenv.config();

import { Pool } from "pg";

if (!process.env.DATABASE_URL) {
  console.log("[Seed] No DATABASE_URL — running in-memory mode needs no seeding.");
  console.log("[Seed] Set DATABASE_URL in .env and re-run to seed PostgreSQL.");
  process.exit(0);
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const NAMED_WARDS = [
  { id: 1,  name: "Rajpur Road" },       { id: 2,  name: "Clement Town" },
  { id: 3,  name: "Patel Nagar" },       { id: 4,  name: "Dalanwala" },
  { id: 5,  name: "Raipur Road" },       { id: 6,  name: "Saharanpur Road" },
  { id: 7,  name: "Dharampur" },         { id: 8,  name: "Doiwala" },
  { id: 9,  name: "Rishikesh" },         { id: 10, name: "Vikasnagar" },
  { id: 11, name: "Haridwar City" },     { id: 12, name: "Jwalapur" },
  { id: 13, name: "Roorkee" },           { id: 14, name: "Manglaur" },
  { id: 15, name: "Bhagwanpur" },        { id: 16, name: "Nainital Town" },
  { id: 17, name: "Haldwani" },          { id: 18, name: "Bhimtal" },
  { id: 19, name: "Ramnagar" },          { id: 20, name: "Kaladhungi" },
  { id: 21, name: "Rudrapur" },          { id: 22, name: "Kashipur" },
  { id: 23, name: "Sitarganj" },         { id: 24, name: "Khatima" },
  { id: 25, name: "Almora Town" },       { id: 26, name: "Ranikhet" },
  { id: 27, name: "Bageshwar Town" },    { id: 28, name: "Pithoragarh Town" },
  { id: 29, name: "Dharchula" },         { id: 30, name: "Gopeshwar" },
  { id: 31, name: "Joshimath" },         { id: 32, name: "Uttarkashi Town" },
  { id: 33, name: "Barkot" },            { id: 34, name: "Tehri Town" },
  { id: 35, name: "Narendra Nagar" },    { id: 36, name: "Pauri Town" },
  { id: 37, name: "Kotdwar" },           { id: 38, name: "Champawat Town" },
  { id: 39, name: "Tanakpur" },          { id: 40, name: "Rudraprayag Town" },
];

const OFFICER_NAMES = [
  "Anil Rawat", "Sunita Negi", "Vikram Bisht", "Kavita Rana", "Deepak Verma",
  "Rekha Joshi", "Mohan Panwar", "Anita Dobhal", "Suresh Badoni", "Nisha Chamoli",
  "Rajendra Bhandari", "Pooja Semwal", "Arjun Riyal", "Meena Pundir", "Sanjay Juyal",
  "Ritu Thapliyal", "Manoj Khanduri", "Anjali Uniyal", "Vinod Lakhera", "Shruti Maikhuri",
];

const CATEGORIES = ["Sanitation", "Roads", "Streetlight", "Water Supply", "Drainage", "Electricity", "Tree", "General Grievance"];
const PRIORITIES = ["P1", "P2", "P3", "P4"];
const WARD_SUBSET = [1, 2, 3, 4, 5, 7, 9, 11, 13, 17, 21, 25, 26, 30, 31, 34, 36, 37, 38, 40];

const MESSAGES = [
  "Nali jamm gayi hai, paani bhar gaya sadak par",
  "Street light kharab hai raat ko andhera rehta hai",
  "Sadak par bada gaḍḍha hai, accident ho sakta hai",
  "Paani ki pipe phoot gayi hai",
  "Kachra uthane wale 3 din se nahi aaye",
  "Bijli ka wire neeche latkaa hua hai, bahut khatarnak hai",
  "Drainage system block ho gaya hai",
  "Garbage not collected for 5 days, causing health hazard",
  "Pothole on main road causing accidents",
  "Water supply disrupted for 2 days in Uttarakhand ward",
];

async function seed() {
  console.log("[Seed] Starting Uttarakhand data seed...");

  // Wards (40)
  for (const ward of NAMED_WARDS) {
    const healthScore = 55 + Math.floor(Math.random() * 40);
    await pool.query(
      `INSERT INTO wards (id, name, health_score) VALUES ($1, $2, $3)
       ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name`,
      [ward.id, ward.name, healthScore]
    );
  }
  console.log("[Seed] 40 Uttarakhand wards seeded");

  // Officers (20) with Uttarakhand GPS coords (lat 29.5–31, lng 78.5–80.5)
  for (let i = 0; i < 20; i++) {
    const wardId = WARD_SUBSET[i % WARD_SUBSET.length];
    const karmaScore = 50 + Math.floor(Math.random() * 45);
    await pool.query(
      `INSERT INTO officers (name, phone, gps_lat, gps_lng, ward_id, karma_score)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (phone) DO NOTHING`,
      [
        OFFICER_NAMES[i],
        `98${String(10000000 + i).padStart(8, "0")}`,
        (29.5 + Math.random() * 1.5).toFixed(7),
        (78.5 + Math.random() * 2.0).toFixed(7),
        wardId,
        karmaScore,
      ]
    );
  }
  console.log("[Seed] 20 Uttarakhand officers seeded");

  // Get officer IDs
  const officerRows = await pool.query(`SELECT id, ward_id FROM officers ORDER BY id`);
  const officers = officerRows.rows;

  // Complaints (50)
  const statuses = ["pending", "assigned", "in_progress", "resolved"];
  for (let i = 0; i < 50; i++) {
    const wardId = WARD_SUBSET[i % WARD_SUBSET.length];
    const officer = officers.find((o: { ward_id: number }) => o.ward_id === wardId) ?? officers[0];
    const category = CATEGORIES[i % CATEGORIES.length];
    const priority = PRIORITIES[i % PRIORITIES.length];
    const statusIndex = i < 20 ? 0 : i < 35 ? 2 : 3;
    const status = statuses[statusIndex];
    const hoursAgo = Math.floor(Math.random() * 72) + 1;
    const createdAt = new Date(Date.now() - hoursAgo * 3600 * 1000);
    const resolvedAt = status === "resolved"
      ? new Date(Date.now() - Math.floor(Math.random() * 24) * 3600 * 1000)
      : null;

    await pool.query(
      `INSERT INTO complaints
         (phone, message, category, priority, ward_id, status, assigned_officer_id, created_at, resolved_at, ai_summary)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [
        `98765${String(43210 + i).padStart(5, "0")}`,
        MESSAGES[i % MESSAGES.length],
        category,
        priority,
        wardId,
        status,
        officer?.id ?? null,
        createdAt,
        resolvedAt,
        `${category} issue reported in ${NAMED_WARDS.find(w => w.id === wardId)?.name ?? "Uttarakhand"}`,
      ]
    );
  }
  console.log("[Seed] 50 complaints seeded");

  // Predictions (Uttarakhand wards)
  const predictions = [
    { ward_id: 11, category: "Drainage",     date: "2026-07-15", confidence: 0.92 },
    { ward_id: 17, category: "Roads",        date: "2026-07-20", confidence: 0.87 },
    { ward_id: 3,  category: "Sanitation",   date: "2026-07-18", confidence: 0.85 },
    { ward_id: 21, category: "Water Supply", date: "2026-07-22", confidence: 0.78 },
    { ward_id: 30, category: "Streetlight",  date: "2026-08-01", confidence: 0.71 },
  ];
  for (const p of predictions) {
    await pool.query(
      `INSERT INTO predictions (ward_id, category, predicted_date, confidence)
       VALUES ($1, $2, $3, $4)`,
      [p.ward_id, p.category, p.date, p.confidence]
    );
  }
  console.log("[Seed] 5 Uttarakhand predictions seeded");

  // Update ward counts
  await pool.query(`
    UPDATE wards w SET
      complaint_count = (SELECT COUNT(*) FROM complaints WHERE ward_id = w.id),
      resolved_count = (SELECT COUNT(*) FROM complaints WHERE ward_id = w.id AND status IN ('resolved','closed'))
  `);
  console.log("[Seed] Ward counts updated");

  await pool.end();
  console.log("[Seed] Done! Uttarakhand data seeded.");
}

seed().catch((err) => {
  console.error("[Seed] Error:", err);
  process.exit(1);
});
