import { Router, Request, Response } from "express";
import jwt from "jsonwebtoken";
import { config } from "../config";
import { DEPARTMENTS, civicStore, getDeptForCategory } from "../db/extensions";
import { store } from "../db/inMemory";

const router = Router();

function requireDeptAuth(req: Request, res: Response, next: () => void) {
  const token = (req.headers.authorization||"").replace("Bearer ","");
  try {
    const payload = jwt.verify(token, config.jwtSecret) as { type: string; departmentId: string };
    if (payload.type !== "dept") { res.status(403).json({ error:"Department token required" }); return; }
    (req as Request & { deptId: string }).deptId = payload.departmentId;
    next();
  } catch { res.status(401).json({ error:"Invalid token" }); }
}

router.post("/api/dept/login", (req: Request, res: Response) => {
  const { departmentId, accessCode } = req.body as { departmentId?:string; accessCode?:string };
  if (!departmentId || !accessCode) { res.status(400).json({ error:"departmentId and accessCode required" }); return; }
  if (accessCode !== `${departmentId}_2026`) { res.status(401).json({ error:"Invalid access code" }); return; }
  const dept = DEPARTMENTS[departmentId];
  if (!dept) { res.status(404).json({ error:"Department not found" }); return; }
  const token = jwt.sign({ departmentId, type:"dept" }, config.jwtSecret, { expiresIn:"12h" });
  res.json({ token, department:dept });
});

router.get("/api/departments", (_req, res) => { res.json(Object.values(DEPARTMENTS)); });

router.get("/api/dept/:deptId/complaints", (req: Request, res: Response) => {
  requireDeptAuth(req, res, () => {
    const all = store.complaints.filter(c => getDeptForCategory(c.category).id === req.params.deptId);
    const enriched = all.map(c => ({
      ...c,
      departmentId: getDeptForCategory(c.category).id,
      departmentName: getDeptForCategory(c.category).name,
      ticketId: `UK-${c.id.slice(0,6).toUpperCase()}`,
      submittedAt: c.created_at,
      district: (() => {
        const ward = store.wards.find(w => w.id === c.ward_id) as unknown as { district?: string }|undefined;
        return ward?.district || "Dehradun";
      })(),
    }));
    res.json({ complaints:enriched, total:enriched.length });
  });
});

router.get("/api/dept/:deptId/stats", (req: Request, res: Response) => {
  requireDeptAuth(req, res, () => {
    const all = store.complaints.filter(c => getDeptForCategory(c.category).id === req.params.deptId);
    const now = Date.now(); const day = 86400000;
    res.json({
      total: all.length,
      pending: all.filter(c=>c.status==="pending"||c.status==="assigned").length,
      inProgress: all.filter(c=>c.status==="in_progress").length,
      resolved: all.filter(c=>c.status==="resolved"||c.status==="closed").length,
      p1Critical: all.filter(c=>c.priority==="P1").length,
      todayCount: all.filter(c=>now-new Date(c.created_at).getTime()<day).length,
      weekCount: all.filter(c=>now-new Date(c.created_at).getTime()<7*day).length,
    });
  });
});

router.put("/api/dept/complaints/:id", (req: Request, res: Response) => {
  requireDeptAuth(req, res, () => {
    const complaint = store.complaints.find(c => c.id===req.params.id);
    if (!complaint) { res.status(404).json({ error:"Not found" }); return; }
    const { status } = req.body as { status?:string };
    if (status) (complaint as unknown as Record<string,unknown>).status = status;
    res.json(complaint);
  });
});

router.get("/api/dept/:deptId/stream", (req: Request, res: Response) => {
  res.setHeader("Content-Type","text/event-stream");
  res.setHeader("Cache-Control","no-cache");
  res.setHeader("Connection","keep-alive");
  res.setHeader("Access-Control-Allow-Origin","*");
  res.flushHeaders();
  const hb = setInterval(() => res.write(`data: ${JSON.stringify({type:"ping"})}\n\n`), 25000);
  const listener = (ev: unknown) => {
    const e = ev as { type:string; departmentId?:string };
    if ((e.type==="complaint_new"&&e.departmentId===req.params.deptId)||e.type==="sla_escalation") {
      res.write(`data: ${JSON.stringify(ev)}\n\n`);
    }
  };
  civicStore.addListener(listener);
  req.on("close", () => { clearInterval(hb); civicStore.removeListener(listener); });
});

export default router;
