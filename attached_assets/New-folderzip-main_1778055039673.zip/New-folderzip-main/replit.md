# SANKALP AI — Uttarakhand Civic Intelligence Platform

AI-powered civic governance system for Uttarakhand: complaint management, department portals, CPR safety command with live mobile GPS, RTI filing, polls, petitions, and real-time audit trail across 13 districts and 40 wards.

## Run & Operate

| Service | Command | Port |
|---|---|---|
| Backend API | `cd backend && npm run dev` | 3001 |
| Frontend (Next.js) | `cd sankalp-ai && npm run dev -- --port 5000` | 5000 |

**Required env vars:** None (runs fully in-memory by default)  
**Optional:** `GEMINI_API_KEY`, `DATABASE_URL` (PostgreSQL), `REDIS_URL`, `JWT_SECRET`  
**Demo token:** `demo-token-offline` (bypasses auth for testing)  
**Dept login codes:** `{deptId}_2026` e.g. `pwd_2026`, `upcl_2026`

## Stack

- **Backend:** Node.js 20, Express 4, Socket.IO, TypeScript, tsx (hot reload), multer, jsonwebtoken
- **Frontend:** Next.js 16 (App Router), React 18, Framer Motion, Leaflet (maps)
- **Storage:** In-memory store (no DB required); PostgreSQL path available via `DATABASE_URL`
- **Queue:** In-memory setTimeout fallback; Bull/Redis when `REDIS_URL` is set

## Where things live

```
backend/
  src/
    db/inMemory.ts      — Ward/officer/complaint in-memory store (40 UK wards)
    db/extensions.ts    — CivicStore: patrols, incidents, RTI, polls, petitions
    routes/dept.ts      — Department portal API + SSE stream
    routes/cpr.ts       — CPR patrol/incident API + SSE stream
    routes/civic.ts     — RTI, polls, petitions, messages, public reports
    routes/upload.ts    — Multer file upload (photos/docs)
    middleware/auth.ts  — JWT + demo-token-offline bypass
  web/
    dept/index.html     — Standalone Department Portal (React CDN)
    cpr/index.html      — CPR Safety Command (Leaflet map, mobile GPS)
    public/index.html   — Uttarakhand Civic Health Dashboard
    rti/index.html      — RTI Filing Portal with AI draft
  uploads/              — Uploaded complaint/resolution/SOS photos

sankalp-ai/
  src/app/              — Next.js pages and components
  next.config.ts        — Rewrites: /api/*, /web/*, /uploads/* → backend:3001
```

## Architecture decisions

- **In-memory only:** No database required for demo/pilot. All data lives in `store` (InMemoryStore) and `civicStore` (CivicStore). Data resets on restart.
- **Dual store pattern:** `store` (inMemory.ts) handles legacy complaints/officers/wards; `civicStore` (extensions.ts) handles new civic features. Both are imported where needed.
- **SSE for real-time:** Server-Sent Events (not WebSocket) for CPR patrol location updates and incident alerts — works behind Replit's TLS proxy without extra setup.
- **Standalone HTML portals:** Dept/CPR/RTI/Public portals are self-contained HTML files (React CDN) served as static files from Express. No build step needed.
- **JWT + demo bypass:** All auth middleware accepts `demo-token-offline` to allow hackathon demos without login flow.
- **Next.js rewrites:** Frontend proxies `/web/*` and `/api/*` to backend, so everything runs through port 5000 for users.

## Product

- **Department Portal** `/web/dept/` — Login with dept code, view live complaint feed filtered by department, acknowledge complaints, real-time SSE stream
- **CPR Safety Command** `/web/cpr/` — Live Leaflet map of 12 patrol vans across UK, SOS button with mobile geolocation, auto-dispatch nearest patrol, escalation badges
- **Public Dashboard** `/web/public/` — Open civic health data: department performance, 40 ward health scores, active petitions
- **RTI Portal** `/web/rti/` — AI-drafted RTI applications, submission tracking, 30-day deadline monitoring
- **Complaint System** `/complaint` — File complaints by ward, AI classification, photo upload, duplicate detection, audit trail
- **Polls & Petitions** — District-level civic engagement; petitions auto-escalate at signature threshold

## User preferences

- No placeholder text, no disabled buttons — all features must be functional
- Uttarakhand-specific: 13 districts, 40 wards, UK-specific GPS coordinates (lat 29-31, lng 78-81)
- All portals accessible from the frontend navbar without separate login to backend

## Gotchas

- `CATEGORIES` in inMemory.ts includes both display names ("Roads") and API keys ("pothole") — `getDeptForCategory()` in extensions.ts matches both
- `buildWards()` now returns `(Ward & { district: string })[]` — cast to `unknown` then target type when accessing `.district`
- CPR patrol simulation runs every 8 seconds and broadcasts to SSE listeners — don't add more frequent simulations
- Ward IDs 1-40 only; `buildComplaints()` now uses `wards.length` not a hardcoded 50

## Pointers

- Workflow skill: `.local/skills/workflows/SKILL.md`
- Package management: `.local/skills/package-management/SKILL.md`
- Backend health: `http://localhost:3001/health`
