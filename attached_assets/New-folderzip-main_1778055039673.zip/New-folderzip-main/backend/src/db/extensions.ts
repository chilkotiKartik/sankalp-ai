import { v4 as uuidv4 } from "uuid";
import crypto from "crypto";

// ─── Uttarakhand Districts & Wards ────────────────────────────────────────────

export const UK_DISTRICTS = [
  "Dehradun", "Haridwar", "Nainital", "Udham Singh Nagar", "Almora",
  "Pithoragarh", "Chamoli", "Uttarkashi", "Tehri Garhwal", "Pauri Garhwal",
  "Champawat", "Bageshwar", "Rudraprayag",
];

export const UK_WARDS: Array<{ id: number; name: string; district: string }> = [
  // Dehradun
  { id: 1, name: "Rajpur Road", district: "Dehradun" },
  { id: 2, name: "Clement Town", district: "Dehradun" },
  { id: 3, name: "Patel Nagar", district: "Dehradun" },
  { id: 4, name: "Dalanwala", district: "Dehradun" },
  { id: 5, name: "Raipur Road", district: "Dehradun" },
  { id: 6, name: "Saharanpur Road", district: "Dehradun" },
  { id: 7, name: "Dharampur", district: "Dehradun" },
  { id: 8, name: "Doiwala", district: "Dehradun" },
  { id: 9, name: "Rishikesh", district: "Dehradun" },
  { id: 10, name: "Vikasnagar", district: "Dehradun" },
  // Haridwar
  { id: 11, name: "Haridwar City", district: "Haridwar" },
  { id: 12, name: "Jwalapur", district: "Haridwar" },
  { id: 13, name: "Roorkee", district: "Haridwar" },
  { id: 14, name: "Manglaur", district: "Haridwar" },
  { id: 15, name: "Bhagwanpur", district: "Haridwar" },
  // Nainital
  { id: 16, name: "Nainital Town", district: "Nainital" },
  { id: 17, name: "Haldwani", district: "Nainital" },
  { id: 18, name: "Bhimtal", district: "Nainital" },
  { id: 19, name: "Ramnagar", district: "Nainital" },
  { id: 20, name: "Kaladhungi", district: "Nainital" },
  // Udham Singh Nagar
  { id: 21, name: "Rudrapur", district: "Udham Singh Nagar" },
  { id: 22, name: "Kashipur", district: "Udham Singh Nagar" },
  { id: 23, name: "Sitarganj", district: "Udham Singh Nagar" },
  { id: 24, name: "Khatima", district: "Udham Singh Nagar" },
  // Almora
  { id: 25, name: "Almora Town", district: "Almora" },
  { id: 26, name: "Ranikhet", district: "Almora" },
  { id: 27, name: "Bageshwar Town", district: "Bageshwar" },
  // Pithoragarh
  { id: 28, name: "Pithoragarh Town", district: "Pithoragarh" },
  { id: 29, name: "Dharchula", district: "Pithoragarh" },
  // Chamoli
  { id: 30, name: "Gopeshwar", district: "Chamoli" },
  { id: 31, name: "Joshimath", district: "Chamoli" },
  // Uttarkashi
  { id: 32, name: "Uttarkashi Town", district: "Uttarkashi" },
  { id: 33, name: "Barkot", district: "Uttarkashi" },
  // Tehri
  { id: 34, name: "Tehri Town", district: "Tehri Garhwal" },
  { id: 35, name: "Narendra Nagar", district: "Tehri Garhwal" },
  // Pauri
  { id: 36, name: "Pauri Town", district: "Pauri Garhwal" },
  { id: 37, name: "Kotdwar", district: "Pauri Garhwal" },
  // Champawat
  { id: 38, name: "Champawat Town", district: "Champawat" },
  { id: 39, name: "Tanakpur", district: "Champawat" },
  // Rudraprayag
  { id: 40, name: "Rudraprayag Town", district: "Rudraprayag" },
];

// ─── Department Config ────────────────────────────────────────────────────────

export interface DepartmentConfig {
  id: string;
  name: string;
  nameHindi: string;
  shortName: string;
  color: string;
  icon: string;
  helpline: string;
  slaHours: number;
  categories: string[];
}

export const DEPARTMENTS: Record<string, DepartmentConfig> = {
  pwd:    { id:"pwd",    name:"PWD — Public Works Department",        nameHindi:"लोक निर्माण विभाग",           shortName:"PWD",          color:"#F59E0B", icon:"🏗️", helpline:"1800-180-4244", slaHours:24, categories:["Roads","pothole","other","General Grievance"] },
  ulb:    { id:"ulb",   name:"Urban Local Body — Municipal Corp.",    nameHindi:"नगर पालिका / नगर निगम",        shortName:"ULB",          color:"#10B981", icon:"🗑️", helpline:"1533",          slaHours:48, categories:["Sanitation","garbage","drain","Drainage"] },
  jal:    { id:"jal",   name:"Uttarakhand Jal Sansthan",             nameHindi:"उत्तराखण्ड जल संस्थान",        shortName:"Jal Sansthan", color:"#3B82F6", icon:"💧", helpline:"1916",          slaHours:12, categories:["Water Supply","water"] },
  upcl:   { id:"upcl",  name:"UPCL — Uttarakhand Power Corp.",       nameHindi:"उत्तराखण्ड पावर कॉर्पोरेशन",  shortName:"UPCL",         color:"#8B5CF6", icon:"⚡", helpline:"1912",          slaHours:6,  categories:["Electricity","electricity","Streetlight","streetlight"] },
  forest: { id:"forest",name:"Forest Department Uttarakhand",        nameHindi:"वन विभाग",                     shortName:"Forest",       color:"#166534", icon:"🌳", helpline:"1800-180-4288", slaHours:96, categories:["Tree","tree"] },
  health: { id:"health",name:"Health & Family Welfare Dept.",        nameHindi:"स्वास्थ्य विभाग",              shortName:"Health",       color:"#EF4444", icon:"🏥", helpline:"104",           slaHours:24, categories:[] },
  usdma:  { id:"usdma", name:"USDMA — Disaster Management Auth.",    nameHindi:"आपदा प्रबंधन प्राधिकरण",      shortName:"USDMA",        color:"#DC2626", icon:"🆘", helpline:"1070",          slaHours:2,  categories:[] },
  police: { id:"police",name:"Uttarakhand Police",                   nameHindi:"उत्तराखण्ड पुलिस",             shortName:"Police",       color:"#1E3A5F", icon:"🚔", helpline:"100",           slaHours:1,  categories:[] },
};

export function getDeptForCategory(category: string): DepartmentConfig {
  return Object.values(DEPARTMENTS).find(d => d.categories.includes(category)) || DEPARTMENTS.pwd;
}

// ─── GeoPoint ─────────────────────────────────────────────────────────────────

export interface GeoPoint { lat: number; lng: number; }

function distKm(a: GeoPoint, b: GeoPoint): number {
  const R = 6371;
  const dLat = (b.lat - a.lat) * Math.PI / 180;
  const dLng = (b.lng - a.lng) * Math.PI / 180;
  const s = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(a.lat * Math.PI/180) * Math.cos(b.lat * Math.PI/180) *
    Math.sin(dLng/2) * Math.sin(dLng/2);
  return R * 2 * Math.atan2(Math.sqrt(s), Math.sqrt(1-s));
}

// ─── Patrol Vans ─────────────────────────────────────────────────────────────

export type PatrolStatus = "active_patrol" | "responding" | "on_break" | "off_duty";

export interface PatrolVan {
  id: string; vanNumber: string; district: string; zone: string;
  officerInCharge: string; officerPhone: string; crewCount: number;
  status: PatrolStatus; shift: "day"|"evening"|"night";
  geo: GeoPoint; lastLocationAt: string; isWomenSafetyUnit: boolean;
  currentIncidentId?: string; eta?: number;
}

const PATROL_VANS_SEED: PatrolVan[] = [
  { id:"pv1",  vanNumber:"UK07-PA-0042", district:"Dehradun",          zone:"Dehradun North",   officerInCharge:"SI Prakash Rawat",  officerPhone:"9456781001", crewCount:3, status:"active_patrol", shift:"night",   geo:{lat:30.338,lng:78.045}, lastLocationAt:new Date().toISOString(), isWomenSafetyUnit:true },
  { id:"pv2",  vanNumber:"UK07-PA-0061", district:"Dehradun",          zone:"Dehradun South",   officerInCharge:"SI Meena Bisht",    officerPhone:"9456781002", crewCount:4, status:"active_patrol", shift:"night",   geo:{lat:30.295,lng:78.018}, lastLocationAt:new Date().toISOString(), isWomenSafetyUnit:true },
  { id:"pv3",  vanNumber:"UK07-PA-0078", district:"Dehradun",          zone:"Vikasnagar Area",  officerInCharge:"HC Suresh Negi",    officerPhone:"9456781003", crewCount:2, status:"active_patrol", shift:"evening", geo:{lat:30.449,lng:77.780}, lastLocationAt:new Date().toISOString(), isWomenSafetyUnit:false },
  { id:"pv4",  vanNumber:"UK01-PA-0023", district:"Haridwar",          zone:"Haridwar City",    officerInCharge:"SI Rekha Sharma",   officerPhone:"9456782001", crewCount:3, status:"active_patrol", shift:"night",   geo:{lat:29.952,lng:78.170}, lastLocationAt:new Date().toISOString(), isWomenSafetyUnit:true },
  { id:"pv5",  vanNumber:"UK01-PA-0044", district:"Haridwar",          zone:"Roorkee Area",     officerInCharge:"HC Anil Kumar",     officerPhone:"9456782002", crewCount:3, status:"active_patrol", shift:"night",   geo:{lat:29.860,lng:77.892}, lastLocationAt:new Date().toISOString(), isWomenSafetyUnit:false },
  { id:"pv6",  vanNumber:"UK09-PA-0015", district:"Nainital",          zone:"Nainital Town",    officerInCharge:"SI Pooja Arya",     officerPhone:"9456783001", crewCount:3, status:"active_patrol", shift:"night",   geo:{lat:29.385,lng:79.468}, lastLocationAt:new Date().toISOString(), isWomenSafetyUnit:true },
  { id:"pv7",  vanNumber:"UK09-PA-0033", district:"Nainital",          zone:"Haldwani Area",    officerInCharge:"HC Deepak Joshi",   officerPhone:"9456783002", crewCount:4, status:"active_patrol", shift:"night",   geo:{lat:29.225,lng:79.520}, lastLocationAt:new Date().toISOString(), isWomenSafetyUnit:false },
  { id:"pv8",  vanNumber:"UK10-PA-0027", district:"Udham Singh Nagar", zone:"Rudrapur City",    officerInCharge:"SI Sunita Devi",    officerPhone:"9456784001", crewCount:3, status:"active_patrol", shift:"night",   geo:{lat:28.990,lng:79.410}, lastLocationAt:new Date().toISOString(), isWomenSafetyUnit:true },
  { id:"pv9",  vanNumber:"UK06-PA-0011", district:"Pithoragarh",       zone:"Pithoragarh Town", officerInCharge:"SI Geeta Mehta",    officerPhone:"9456785001", crewCount:3, status:"active_patrol", shift:"night",   geo:{lat:29.588,lng:80.222}, lastLocationAt:new Date().toISOString(), isWomenSafetyUnit:true },
  { id:"pv10", vanNumber:"UK03-PA-0019", district:"Almora",            zone:"Almora Town",      officerInCharge:"SI Kamla Pant",     officerPhone:"9456786001", crewCount:3, status:"active_patrol", shift:"night",   geo:{lat:29.602,lng:79.659}, lastLocationAt:new Date().toISOString(), isWomenSafetyUnit:true },
  { id:"pv11", vanNumber:"UK11-PA-0008", district:"Uttarkashi",        zone:"Uttarkashi Town",  officerInCharge:"HC Vinod Semwal",   officerPhone:"9456787001", crewCount:2, status:"active_patrol", shift:"night",   geo:{lat:30.732,lng:78.440}, lastLocationAt:new Date().toISOString(), isWomenSafetyUnit:false },
  { id:"pv12", vanNumber:"UK05-PA-0031", district:"Chamoli",           zone:"Gopeshwar",        officerInCharge:"SI Devi Lal",       officerPhone:"9456788001", crewCount:3, status:"active_patrol", shift:"evening", geo:{lat:30.396,lng:79.320}, lastLocationAt:new Date().toISOString(), isWomenSafetyUnit:true },
];

// ─── Safety Incidents ─────────────────────────────────────────────────────────

export interface SafetyIncident {
  id: string; sosId: string; citizenName: string; location: string;
  geo: GeoPoint; district: string; reportedAt: string;
  status: "active"|"patrol_dispatched"|"police_responding"|"safe"|"closed";
  assignedPatrolId?: string; assignedPatrolVan?: string;
  assignedPatrolOfficer?: string; assignedPatrolPhone?: string;
  escalationLevel: number; eta?: number; safeConfirmedAt?: string;
  nearestSafe: Array<{ name:string; type:string; phone:string; distKm:number }>;
  updates: Array<{ timestamp:string; type:string; message:string; actor:string }>;
}

// ─── Messages ─────────────────────────────────────────────────────────────────

export interface ChatMessage {
  id: string; complaintId: string; senderId: string; senderName: string;
  senderRole: string; content: string; isRead: boolean; createdAt: string;
}

// ─── RTI ─────────────────────────────────────────────────────────────────────

export interface RTIRequest {
  id: string; userId: string; userName: string; title: string;
  questionText: string; targetDepartment: string;
  status: "drafted"|"submitted"|"response_received"|"overdue";
  submittedAt?: string; deadline?: string; responseText?: string;
  responseAt?: string; aiDraftUsed: boolean; district: string; createdAt: string;
}

// ─── Polls ────────────────────────────────────────────────────────────────────

export interface Poll {
  id: string; wardId?: number; district: string; question: string;
  options: string[]; votes: Record<string,number>; voterIds: string[];
  createdBy: string; endsAt: string; isActive: boolean; createdAt: string;
}

// ─── Petitions ────────────────────────────────────────────────────────────────

export interface Petition {
  id: string; title: string; description: string;
  createdBy: string; creatorName: string; district: string; ward?: string;
  threshold: number; signatureCount: number; signerIds: string[];
  status: "active"|"escalated"|"responded"|"closed";
  officialResponse?: string; respondedBy?: string;
  respondedAt?: string; escalatedAt?: string; createdAt: string;
}

// ─── Shared police stations (for CPR safe locations) ──────────────────────────

const UK_POLICE_STATIONS = [
  { name:"Dehradun Kotwali", district:"Dehradun",    geo:{lat:30.322,lng:78.032}, phone:"0135-2654321" },
  { name:"Rajpur Police Post",district:"Dehradun",   geo:{lat:30.352,lng:78.073}, phone:"0135-2654322" },
  { name:"Haridwar Kotwali", district:"Haridwar",    geo:{lat:29.959,lng:78.163}, phone:"01334-227111" },
  { name:"Roorkee Police",   district:"Haridwar",    geo:{lat:29.861,lng:77.892}, phone:"01332-272222" },
  { name:"Nainital Kotwali", district:"Nainital",    geo:{lat:29.380,lng:79.463}, phone:"05942-235200" },
  { name:"Haldwani Police",  district:"Nainital",    geo:{lat:29.219,lng:79.514}, phone:"05946-220300" },
  { name:"Rudrapur Police",  district:"Udham Singh Nagar", geo:{lat:28.983,lng:79.398}, phone:"05944-240100" },
  { name:"Almora Kotwali",   district:"Almora",      geo:{lat:29.597,lng:79.653}, phone:"05962-230100" },
  { name:"Pithoragarh Police",district:"Pithoragarh",geo:{lat:29.581,lng:80.218}, phone:"05964-225200" },
];

// ─── Civic Extended Store ─────────────────────────────────────────────────────

export class CivicStore {
  patrolVans: PatrolVan[] = PATROL_VANS_SEED.map(v => ({ ...v, lastLocationAt: new Date().toISOString() }));
  safetyIncidents: SafetyIncident[] = [];
  chatMessages: ChatMessage[] = [];
  rtiRequests: RTIRequest[] = [];
  polls: Poll[] = [];
  petitions: Petition[] = [];
  private listeners: Array<(ev: object) => void> = [];

  constructor() {
    this.seedPolls();
    this.seedPetitions();
    this.startPatrolSimulation();
  }

  private seedPolls() {
    const now = Date.now();
    this.polls = [
      { id:uuidv4(), district:"Dehradun",    question:"Which area needs road repair most urgently?",              options:["Rajpur Road","Clement Town","Patel Nagar","Dalanwala"],             votes:{"Rajpur Road":34,"Clement Town":12,"Patel Nagar":28,"Dalanwala":9},     voterIds:[], createdBy:"system", endsAt:new Date(now+7*86400000).toISOString(), isActive:true, createdAt:new Date().toISOString() },
      { id:uuidv4(), district:"Haridwar",    question:"Which issue should the municipality prioritize this month?",options:["Garbage collection","Streetlights","Drainage","Water supply"],      votes:{"Garbage collection":45,"Streetlights":18,"Drainage":37,"Water supply":22},voterIds:[], createdBy:"system", endsAt:new Date(now+5*86400000).toISOString(), isActive:true, createdAt:new Date().toISOString() },
      { id:uuidv4(), district:"Champawat",   question:"Do you want a new park in Ward 4?",                        options:["Yes, strongly","Yes, but not priority","No","Need more info"],       votes:{"Yes, strongly":67,"Yes, but not priority":23,"No":8,"Need more info":14}, voterIds:[], createdBy:"system", endsAt:new Date(now+10*86400000).toISOString(),isActive:true, createdAt:new Date().toISOString() },
      { id:uuidv4(), district:"Nainital",    question:"Rate the quality of drinking water in your area",          options:["Excellent","Good","Average","Poor"],                                 votes:{"Excellent":12,"Good":34,"Average":45,"Poor":28},                        voterIds:[], createdBy:"system", endsAt:new Date(now+3*86400000).toISOString(),  isActive:true, createdAt:new Date().toISOString() },
    ];
  }

  private seedPetitions() {
    const ago = (h:number) => new Date(Date.now()-h*3600000).toISOString();
    this.petitions = [
      { id:uuidv4(), title:"Fix the Haridwar Bypass pothole cluster",              description:"There are 14 dangerous potholes on the 3km stretch of Haridwar Bypass near Shyampur. Vehicles are damaged daily. We demand immediate repair.",                                        createdBy:"citizen1", creatorName:"Ramesh Rawat",  district:"Haridwar", threshold:200, signatureCount:156, signerIds:[], status:"active",    createdAt:ago(72) },
      { id:uuidv4(), title:"Install streetlights on Vikasnagar Forest Road",       description:"The 2km forest road connecting Vikasnagar to NH58 has no streetlights. Women fear travelling at night. We urgently request solar streetlight installation.",                           createdBy:"citizen2", creatorName:"Priya Bisht",   district:"Dehradun", threshold:100, signatureCount:98,  signerIds:[], status:"active",    createdAt:ago(48) },
      { id:uuidv4(), title:"Restore clean drinking water supply in Haldwani Ward 7",description:"Water supply has been contaminated for 3 weeks in Haldwani Ward 7. Children are falling ill. Jal Sansthan must provide clean water immediately.",                                      createdBy:"citizen3", creatorName:"Sunita Devi",   district:"Nainital", threshold:300, signatureCount:312, signerIds:[], status:"escalated", createdAt:ago(96), escalatedAt:ago(24) },
    ];
  }

  private startPatrolSimulation() {
    setInterval(() => {
      this.patrolVans.forEach(v => {
        if (v.status !== "off_duty") {
          v.geo = { lat: v.geo.lat + (Math.random()-0.5)*0.002, lng: v.geo.lng + (Math.random()-0.5)*0.002 };
          v.lastLocationAt = new Date().toISOString();
        }
      });
      this.broadcast({ type:"patrol_locations_batch", vans: this.patrolVans.map(v => ({ id:v.id, geo:v.geo, status:v.status })) });
    }, 8000);
  }

  broadcast(ev: object) {
    this.listeners.forEach(l => l(ev));
  }
  addListener(l: (ev: object) => void) { this.listeners.push(l); }
  removeListener(l: (ev: object) => void) { this.listeners = this.listeners.filter(x => x !== l); }

  // ── Patrol Vans ──────────────────────────────────────────────────────────────
  getPatrolVans(district?: string) {
    return district ? this.patrolVans.filter(v => v.district === district) : [...this.patrolVans];
  }
  getNearestPatrols(geo: GeoPoint, count=3, district?: string) {
    const active = this.patrolVans.filter(v => v.status==="active_patrol" && (!district || v.district===district));
    return active.map(v => ({ ...v, distKm: distKm(geo, v.geo) })).sort((a,b)=>a.distKm-b.distKm).slice(0, count);
  }
  updatePatrolLocation(id: string, geo: GeoPoint): PatrolVan|null {
    const v = this.patrolVans.find(x => x.id===id);
    if (!v) return null;
    v.geo = geo; v.lastLocationAt = new Date().toISOString();
    return v;
  }
  dispatchPatrol(patrolId: string, incidentId: string): PatrolVan|null {
    const v = this.patrolVans.find(x => x.id===patrolId);
    if (!v) return null;
    v.status = "responding"; v.currentIncidentId = incidentId;
    return v;
  }
  freePatrol(patrolId: string) {
    const v = this.patrolVans.find(x => x.id===patrolId);
    if (v) { v.status="active_patrol"; v.currentIncidentId=undefined; }
  }

  // ── Safety Incidents ─────────────────────────────────────────────────────────
  createSafetyIncident(geo: GeoPoint, location: string, district: string, citizenName: string, sosId: string): SafetyIncident {
    const nearest = this.getNearestPatrols(geo, 3, district);
    const nearestPolice = UK_POLICE_STATIONS
      .filter(ps => !district || ps.district===district)
      .map(ps => ({ name:ps.name, type:"police_station", phone:ps.phone, distKm:distKm(geo, ps.geo) }))
      .sort((a,b) => a.distKm-b.distKm).slice(0, 3);

    const inc: SafetyIncident = {
      id: uuidv4(), sosId, citizenName, location, geo, district,
      reportedAt: new Date().toISOString(),
      status: "active", escalationLevel: 0,
      nearestSafe: nearestPolice,
      updates: [{ timestamp:new Date().toISOString(), type:"created", message:`Safety incident created. ${nearest.length} patrol van(s) identified nearby.`, actor:"SANKALP AI" }],
    };
    if (nearest.length > 0) {
      const n = nearest[0];
      inc.assignedPatrolId = n.id; inc.assignedPatrolVan = n.vanNumber;
      inc.assignedPatrolOfficer = n.officerInCharge; inc.assignedPatrolPhone = n.officerPhone;
      inc.status = "patrol_dispatched"; inc.escalationLevel = 1;
      inc.eta = Math.round(n.distKm * 3);
      inc.updates.push({ timestamp:new Date().toISOString(), type:"patrol_dispatched",
        message:`Patrol van ${n.vanNumber} auto-dispatched. Distance: ${n.distKm.toFixed(1)} km. ETA ~${inc.eta} min. Officer: ${n.officerInCharge} (${n.officerPhone})`,
        actor:"Auto-dispatch" });
      this.dispatchPatrol(n.id, inc.id);
    }
    this.safetyIncidents.unshift(inc);
    this.broadcast({ type:"safety_incident_new", incident:inc, nearestPatrols:nearest, nearestSafe:nearestPolice });
    return inc;
  }

  getSafetyIncidents(district?: string) {
    return district ? this.safetyIncidents.filter(i => i.district===district) : [...this.safetyIncidents];
  }
  updateIncidentStatus(id: string, status: SafetyIncident["status"], message: string, actor: string): SafetyIncident|null {
    const inc = this.safetyIncidents.find(x => x.id===id);
    if (!inc) return null;
    inc.status = status;
    if (status==="safe"||status==="closed") inc.safeConfirmedAt = new Date().toISOString();
    inc.updates.push({ timestamp:new Date().toISOString(), type:status, message, actor });
    if (status==="safe" && inc.assignedPatrolId) this.freePatrol(inc.assignedPatrolId);
    this.broadcast({ type:"incident_updated", incident:inc });
    return inc;
  }
  escalateIncident(id: string, level: number): SafetyIncident|null {
    const inc = this.safetyIncidents.find(x => x.id===id);
    if (!inc) return null;
    inc.escalationLevel = level;
    const msgs: Record<number,string> = {
      2:"No patrol response in 5 min. Auto-escalating to DSP level.",
      3:"10 min with no response. Escalated to Superintendent of Police.",
      4:"CRITICAL: 15+ min unresolved. Alerting DGP & State Control Room.",
    };
    inc.updates.push({ timestamp:new Date().toISOString(), type:"escalated", message:msgs[level]||"Escalated", actor:"SANKALP AI Auto-Escalation" });
    this.broadcast({ type:"incident_escalated", incident:inc, level, urgency:level>=3?"critical":"high" });
    return inc;
  }

  // ── Messages ─────────────────────────────────────────────────────────────────
  getMessages(complaintId: string) {
    return this.chatMessages.filter(m => m.complaintId===complaintId).sort((a,b) => new Date(a.createdAt).getTime()-new Date(b.createdAt).getTime());
  }
  createMessage(data: Omit<ChatMessage,"id"|"isRead"|"createdAt">): ChatMessage {
    const msg: ChatMessage = { ...data, id:uuidv4(), isRead:false, createdAt:new Date().toISOString() };
    this.chatMessages.push(msg);
    this.broadcast({ type:"message_new", message:msg, complaintId:data.complaintId });
    return msg;
  }
  markMessagesRead(complaintId: string, readerId: string) {
    this.chatMessages.filter(m => m.complaintId===complaintId && m.senderId!==readerId).forEach(m => { m.isRead=true; });
  }

  // ── RTI ──────────────────────────────────────────────────────────────────────
  getRTIs(userId?: string) { return userId ? this.rtiRequests.filter(r => r.userId===userId) : [...this.rtiRequests]; }
  createRTI(data: Omit<RTIRequest,"id"|"createdAt"|"status">): RTIRequest {
    const rti: RTIRequest = { ...data, id:uuidv4(), status:"drafted", createdAt:new Date().toISOString() };
    this.rtiRequests.push(rti); return rti;
  }
  submitRTI(id: string): RTIRequest|null {
    const rti = this.rtiRequests.find(r => r.id===id);
    if (!rti) return null;
    rti.status="submitted"; rti.submittedAt=new Date().toISOString();
    const dl = new Date(); dl.setDate(dl.getDate()+30); rti.deadline=dl.toISOString();
    return rti;
  }
  respondRTI(id: string, responseText: string, respondedBy: string): RTIRequest|null {
    const rti = this.rtiRequests.find(r => r.id===id);
    if (!rti) return null;
    rti.status="response_received"; rti.responseText=responseText; rti.responseAt=new Date().toISOString();
    return rti;
  }

  // ── Polls ─────────────────────────────────────────────────────────────────────
  getPolls(district?: string) {
    const now = new Date();
    return (district ? this.polls.filter(p => p.district===district) : [...this.polls])
      .map(p => ({ ...p, isActive: p.isActive && new Date(p.endsAt)>now }));
  }
  createPoll(data: Omit<Poll,"id"|"votes"|"voterIds"|"isActive"|"createdAt">): Poll {
    const votes: Record<string,number> = {}; data.options.forEach(o => { votes[o]=0; });
    const poll: Poll = { ...data, id:uuidv4(), votes, voterIds:[], isActive:true, createdAt:new Date().toISOString() };
    this.polls.push(poll); return poll;
  }
  votePoll(pollId: string, option: string, userId: string): Poll|null {
    const poll = this.polls.find(p => p.id===pollId);
    if (!poll || poll.voterIds.includes(userId) || !poll.isActive) return null;
    poll.votes[option]=(poll.votes[option]||0)+1; poll.voterIds.push(userId);
    this.broadcast({ type:"poll_vote", pollId, votes:poll.votes });
    return poll;
  }

  // ── Petitions ─────────────────────────────────────────────────────────────────
  getPetitions(district?: string) { return district ? this.petitions.filter(p => p.district===district) : [...this.petitions]; }
  createPetition(data: Omit<Petition,"id"|"signatureCount"|"signerIds"|"status"|"createdAt">): Petition {
    const p: Petition = { ...data, id:uuidv4(), signatureCount:0, signerIds:[], status:"active", createdAt:new Date().toISOString() };
    this.petitions.push(p); return p;
  }
  signPetition(petitionId: string, userId: string): Petition|null {
    const p = this.petitions.find(x => x.id===petitionId);
    if (!p || p.signerIds.includes(userId)) return null;
    p.signerIds.push(userId); p.signatureCount++;
    if (p.signatureCount>=p.threshold && p.status==="active") {
      p.status="escalated"; p.escalatedAt=new Date().toISOString();
      this.broadcast({ type:"petition_escalated", petition:p });
    }
    this.broadcast({ type:"petition_signed", petitionId, signatureCount:p.signatureCount });
    return p;
  }
  respondPetition(petitionId: string, response: string, respondedBy: string): Petition|null {
    const p = this.petitions.find(x => x.id===petitionId);
    if (!p) return null;
    p.officialResponse=response; p.respondedBy=respondedBy;
    p.respondedAt=new Date().toISOString(); p.status="responded";
    this.broadcast({ type:"petition_responded", petition:p });
    return p;
  }

  // ── Department Report ────────────────────────────────────────────────────────
  getDepartmentReport(complaints: Array<{ category:string; status:string; priority:string }>) {
    return Object.values(DEPARTMENTS).map(dept => {
      const all = complaints.filter(c => getDeptForCategory(c.category).id===dept.id);
      const resolved = all.filter(c => c.status==="resolved"||c.status==="closed").length;
      const rate = all.length > 0 ? Math.round(resolved/all.length*100) : 0;
      return {
        ...dept, total:all.length, resolved,
        pending:all.filter(c=>c.status==="pending"||c.status==="assigned").length,
        p1Pending:all.filter(c=>c.priority==="P1"&&c.status!=="resolved"&&c.status!=="closed").length,
        resolutionRate:rate, grade:rate>=80?"A":rate>=60?"B":rate>=40?"C":"D",
      };
    });
  }

  // ── CPR Auto-escalation ──────────────────────────────────────────────────────
  runCPREscalation() {
    const now = Date.now();
    this.safetyIncidents.filter(i => i.status==="active"||i.status==="patrol_dispatched").forEach(i => {
      const mins = (now - new Date(i.reportedAt).getTime()) / 60000;
      if (mins>5 && i.escalationLevel<2) this.escalateIncident(i.id, 2);
      else if (mins>10 && i.escalationLevel<3) this.escalateIncident(i.id, 3);
      else if (mins>15 && i.escalationLevel<4) this.escalateIncident(i.id, 4);
    });
  }
}

export const civicStore = new CivicStore();

// Run CPR escalation every 5 minutes
setInterval(() => civicStore.runCPREscalation(), 5 * 60 * 1000);
