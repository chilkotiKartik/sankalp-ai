"use client";

import React, { createContext, useContext, useEffect, useState, ReactNode } from "react";

export interface User {
  id: string;
  name: string;
  phone: string;
  role: "admin" | "citizen" | "field_officer";
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  authLoading: boolean;
  login: (token: string, user: User) => void;
  register: (token: string, user: User) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEMO_USER: User = {
  id: "demo-admin-001",
  name: "Demo Admin",
  phone: "9999999999",
  role: "admin",
};
const DEMO_TOKEN = "demo-token-offline";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  useEffect(() => {
    const storedToken = localStorage.getItem("sankalp_token");
    const storedUser = localStorage.getItem("sankalp_user");

    if (storedToken && storedUser) {
      try {
        setToken(storedToken);
        setUser(JSON.parse(storedUser));
        setAuthLoading(false);
        return;
      } catch {
        localStorage.removeItem("sankalp_token");
        localStorage.removeItem("sankalp_user");
      }
    }

    setToken(DEMO_TOKEN);
    setUser(DEMO_USER);
    localStorage.setItem("sankalp_token", DEMO_TOKEN);
    localStorage.setItem("sankalp_user", JSON.stringify(DEMO_USER));
    setAuthLoading(false);
  }, []);

  const login = (newToken: string, newUser: User) => {
    localStorage.setItem("sankalp_token", newToken);
    localStorage.setItem("sankalp_user", JSON.stringify(newUser));
    setToken(newToken);
    setUser(newUser);
  };

  const register = (newToken: string, newUser: User) => {
    login(newToken, newUser);
  };

  const logout = () => {
    localStorage.removeItem("sankalp_token");
    localStorage.removeItem("sankalp_user");
    setToken(DEMO_TOKEN);
    setUser(DEMO_USER);
    localStorage.setItem("sankalp_token", DEMO_TOKEN);
    localStorage.setItem("sankalp_user", JSON.stringify(DEMO_USER));
  };

  return (
    <AuthContext.Provider value={{ user, token, isAuthenticated: !!token, authLoading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
