import express from "express";
import { createServer } from "http";
import { Server as SocketServer } from "socket.io";
import cors from "cors";
import path from "path";
import { config, useInMemory } from "./config";
import { setIo } from "./sockets/events";
import { initSlaQueue } from "./queues/slaQueue";

// Routes
import authRouter from "./routes/auth";
import complaintsRouter from "./routes/complaints";
import ticketsRouter from "./routes/tickets";
import wardsRouter from "./routes/wards";
import predictionsRouter from "./routes/predictions";
import auditRouter from "./routes/audit";
import adminRouter from "./routes/admin";
import deptRouter from "./routes/dept";
import cprRouter from "./routes/cpr";
import civicRouter from "./routes/civic";
import uploadRouter from "./routes/upload";

const app = express();
const httpServer = createServer(app);

// ─── Socket.IO ────────────────────────────────────────────────────────────────

const io = new SocketServer(httpServer, {
  cors: { origin: "*", methods: ["GET", "POST"] },
});
setIo(io);

io.on("connection", (socket) => {
  console.log(`[WS] Client connected: ${socket.id}`);
  socket.on("disconnect", () => {
    console.log(`[WS] Client disconnected: ${socket.id}`);
  });
});

// ─── Middleware ───────────────────────────────────────────────────────────────

app.use(cors({ origin: "*", credentials: false }));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// Serve static files — web portals
const WEB_DIR = path.join(__dirname, "../web");
app.use("/web", express.static(WEB_DIR));

// Serve uploaded photos
app.use("/uploads", express.static(path.join(__dirname, "../uploads")));

// No-cache headers for dev proxy compatibility
app.use((_req, res, next) => {
  res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
  next();
});

// Request logging
app.use((req, _res, next) => {
  const skip = ["/api/cpr/stream", "/api/dept/", "/api/civic/stream", "/api/cpr/patrols"].some(p => req.path.startsWith(p));
  if (!skip) console.log(`[${new Date().toISOString().slice(11,19)}] ${req.method} ${req.path}`);
  next();
});

// ─── Routes ───────────────────────────────────────────────────────────────────

import { optionalAuth } from "./middleware/auth";

// Department portal (no auth on login endpoint)
app.use(deptRouter);

// CPR + safety (uses requireAuth internally; stream is open)
app.use(cprRouter);

// Upload (uses requireAuth internally)
app.use(uploadRouter);

// Public civic endpoints (some open, some auth)
app.use(civicRouter);

// Existing public routes
app.use(authRouter);
app.use(complaintsRouter);

// Protected routes (optional auth)
app.use(optionalAuth);
app.use(ticketsRouter);
app.use(wardsRouter);
app.use(predictionsRouter);
app.use(auditRouter);
app.use(adminRouter);

// Health check
app.get("/health", (_req, res) => {
  res.json({
    status: "ok",
    version: "2.0",
    region: "Uttarakhand",
    database: useInMemory ? "in-memory" : "postgresql",
    gemini: config.geminiApiKey ? "live" : "local-classifier",
    queue: config.redisUrl ? "bull/redis" : "in-memory-timeout",
    portals: { dept: "/web/dept/", cpr: "/web/cpr/", public: "/web/public/", rti: "/web/rti/" },
    timestamp: new Date().toISOString(),
  });
});

// 404 fallback
app.use((_req, res) => res.status(404).json({ error: "Route not found" }));

// ─── Error handler ────────────────────────────────────────────────────────────

app.use(
  (err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error("[Error]", err.message);
    res.status(500).json({ error: err.message || "Internal server error" });
  }
);

// ─── Boot ─────────────────────────────────────────────────────────────────────

(async () => {
  await initSlaQueue();

  httpServer.listen(config.port, "0.0.0.0", () => {
    console.log("");
    console.log("╔══════════════════════════════════════════════════╗");
    console.log("║     SANKALP AI Backend  v2.0 — Uttarakhand       ║");
    console.log(`║  Port     : ${config.port}                                  ║`);
    console.log(`║  Database : ${useInMemory ? "IN-MEMORY (no PostgreSQL)       " : "PostgreSQL                      "}║`);
    console.log("╠══════════════════════════════════════════════════╣");
    console.log("║  Web Portals:                                    ║");
    console.log(`║    Dept.   → /web/dept/                          ║`);
    console.log(`║    CPR     → /web/cpr/                           ║`);
    console.log(`║    Public  → /web/public/                        ║`);
    console.log(`║    RTI     → /web/rti/                           ║`);
    console.log("╚══════════════════════════════════════════════════╝");
    console.log("");
    console.log(`  Health  → http://localhost:${config.port}/health`);
    console.log(`  API     → http://localhost:${config.port}/api/complaints`);
    console.log("");
  });
})();
