import { Router, Request, Response } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { requireAuth } from "../middleware/auth";

const router = Router();

const UPLOAD_DIR = path.join(__dirname, "../../uploads");
["complaints","resolutions","sos","rti"].forEach(sub => {
  const d = path.join(UPLOAD_DIR, sub);
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
});

const uploadMiddleware = multer({
  storage: multer.diskStorage({
    destination: (req, _f, cb) => {
      const folder = (req as Request & { uploadFolder?:string }).uploadFolder || "complaints";
      cb(null, path.join(UPLOAD_DIR, folder));
    },
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname) || ".jpg";
      cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
    },
  }),
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_r, file, cb) => {
    if (file.mimetype.startsWith("image/")) { cb(null, true); }
    else { cb(new Error("Only image files allowed")); }
  },
});

router.post("/api/upload/complaint-photo", requireAuth, (req: Request, res: Response) => {
  (req as Request & { uploadFolder?:string }).uploadFolder = "complaints";
  uploadMiddleware.single("photo")(req, res, err => {
    if (err || !(req as Request & { file?:Express.Multer.File }).file) {
      res.status(400).json({ error: err?.message || "No file uploaded" }); return;
    }
    const file = (req as Request & { file:Express.Multer.File }).file;
    res.json({ url:`/uploads/complaints/${file.filename}`, filename:file.filename });
  });
});

router.post("/api/upload/resolution-photo", requireAuth, (req: Request, res: Response) => {
  (req as Request & { uploadFolder?:string }).uploadFolder = "resolutions";
  uploadMiddleware.single("photo")(req, res, err => {
    if (err || !(req as Request & { file?:Express.Multer.File }).file) {
      res.status(400).json({ error: err?.message || "No file uploaded" }); return;
    }
    const file = (req as Request & { file:Express.Multer.File }).file;
    res.json({ url:`/uploads/resolutions/${file.filename}`, filename:file.filename });
  });
});

router.post("/api/upload/sos-photo", (req: Request, res: Response) => {
  (req as Request & { uploadFolder?:string }).uploadFolder = "sos";
  uploadMiddleware.single("photo")(req, res, err => {
    if (err || !(req as Request & { file?:Express.Multer.File }).file) {
      res.status(400).json({ error: err?.message || "No file uploaded" }); return;
    }
    const file = (req as Request & { file:Express.Multer.File }).file;
    res.json({ url:`/uploads/sos/${file.filename}`, filename:file.filename });
  });
});

router.post("/api/upload/rti-document", requireAuth, (req: Request, res: Response) => {
  (req as Request & { uploadFolder?:string }).uploadFolder = "rti";
  uploadMiddleware.single("document")(req, res, err => {
    if (err || !(req as Request & { file?:Express.Multer.File }).file) {
      res.status(400).json({ error: err?.message || "No file uploaded" }); return;
    }
    const file = (req as Request & { file:Express.Multer.File }).file;
    res.json({ url:`/uploads/rti/${file.filename}`, filename:file.filename });
  });
});

export default router;
