import React, { useRef, useEffect, useState } from "react";
import {
  View, Text, StyleSheet, ScrollView, Pressable,
  Platform, Animated, RefreshControl, Modal, Linking,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import { NotificationBell } from "@/components/NotificationBell";

const CATEGORY_META: Record<string, { label: string; icon: keyof typeof Ionicons.glyphMap; color: string; bg: string }> = {
  pothole:     { label: "Pothole",     icon: "alert-circle",        color: "#F59E0B", bg: "#FFF8E7" },
  garbage:     { label: "Garbage",     icon: "trash",               color: "#EF4444", bg: "#FEF2F2" },
  streetlight: { label: "Streetlight", icon: "bulb",                color: "#F59E0B", bg: "#FFF8E7" },
  water:       { label: "Water",       icon: "water",               color: "#3B82F6", bg: "#EFF6FF" },
  drain:       { label: "Drain",       icon: "git-network",         color: "#06B6D4", bg: "#F0FDFF" },
  electricity: { label: "Electricity", icon: "flash",               color: "#8B5CF6", bg: "#F5F3FF" },
  tree:        { label: "Tree",        icon: "leaf",                color: "#00A651", bg: "#F0FFF4" },
  other:       { label: "Other",       icon: "ellipsis-horizontal", color: "#6B7280", bg: "#F9FAFB" },
};

const STATUS_META: Record<string, { label: string; color: string; bg: string }> = {
  pending:     { label: "Pending",     color: "#F59E0B", bg: "#FFF8E7" },
  in_progress: { label: "In Progress", color: "#3B82F6", bg: "#EFF6FF" },
  resolved:    { label: "Resolved",    color: "#00A651", bg: "#F0FFF4" },
  closed:      { label: "Closed",      color: "#6B7280", bg: "#F9FAFB" },
};

const SCHEMES_DATA = [
  {
    key: "pmay",
    title: "PM Awas Yojana",
    sub: "Affordable housing for all",
    tag: "HOUSING",
    color: "#3B82F6",
    icon: "home" as const,
    fullTitle: "Pradhan Mantri Awas Yojana (PMAY)",
    tagline: "A home for every Indian family by 2024",
    eligibility: [
      "Annual household income below ₹18 lakh",
      "No pucca house in the family's name anywhere in India",
      "First-time home buyers only",
      "Valid Aadhaar card mandatory",
      "Beneficiary cannot have received housing benefit from any Govt scheme before",
    ],
    benefits: [
      "Credit-linked interest subsidy up to ₹2.67 lakh",
      "Reduced home loan interest at 3–6.5% pa",
      "Support for beneficiary-led construction (BLC) — ₹1.5 lakh grant",
      "Completes Delhi's urban housing policy gap for EWS/LIG/MIG families",
      "Environmental green design incentives",
    ],
    howToApply: "Visit your nearest Common Service Centre (CSC) or Delhi Housing Board office. Apply online at pmaymis.gov.in. Required documents: Aadhaar, income certificate, bank passbook, land ownership proof.",
    helpline: "1800-11-6163",
    website: "pmaymis.gov.in",
  },
  {
    key: "ayushman",
    title: "Ayushman Bharat",
    sub: "₹5 lakh health coverage per family",
    tag: "HEALTH",
    color: "#EF4444",
    icon: "medkit" as const,
    fullTitle: "Ayushman Bharat — Pradhan Mantri Jan Arogya Yojana (AB-PMJAY)",
    tagline: "World's largest government-funded health assurance scheme",
    eligibility: [
      "Identified as beneficiary per SECC-2011 census data",
      "Must be from rural deprived families or urban occupational categories",
      "No cap on family size or age",
      "Existing illness (pre-conditions) are also covered",
      "Not having any existing health insurance from Govt",
    ],
    benefits: [
      "₹5 lakh annual health coverage per family — fully cashless",
      "Covers 1,500+ hospital procedures including cancer, heart surgery, dialysis",
      "Empanelled with 24,000+ hospitals across India including Delhi",
      "No premium payment — 100% government funded",
      "Includes pre and post-hospitalisation costs (3 days before, 15 days after)",
    ],
    howToApply: "Visit nearest Jan Seva Kendra or empanelled hospital. Search eligibility at pmjay.gov.in. Carry Aadhaar and ration card. Free Ayushman card issued on-spot.",
    helpline: "14555",
    website: "pmjay.gov.in",
  },
  {
    key: "ration",
    title: "Delhi Ration Card",
    sub: "Subsidised food grains",
    tag: "FOOD",
    color: "#00A651",
    icon: "fast-food" as const,
    fullTitle: "Delhi Public Distribution System — Ration Card",
    tagline: "Subsidised essential food for Delhi's poor families",
    eligibility: [
      "Must be a Delhi resident with proof of residence",
      "Annual family income below ₹1 lakh for APL card; BPL status for priority card",
      "Should not own more than 100 sq. mt. residential property",
      "No vehicle (four-wheeler) in family",
      "Not paying income tax",
    ],
    benefits: [
      "Priority Household (PHH): 5 kg grains/person/month at ₹2–3/kg",
      "Antyodaya Anna Yojana (AAY): 35 kg/family/month at subsidised rate",
      "Edible oil, sugar, salt at subsidised rates",
      "Can be used to apply for Ayushman Bharat and PMAY",
      "Required for scholarship and social welfare applications",
    ],
    howToApply: "Apply online at nfs.delhi.gov.in or at your local Food & Civil Supplies office. Required: Aadhaar, proof of residence (rent agreement / voter ID), income certificate, passport photos.",
    helpline: "1967",
    website: "nfs.delhi.gov.in",
  },
  {
    key: "edistrict",
    title: "e-District Services",
    sub: "Digital certificates & documents",
    tag: "DIGITAL",
    color: "#8B5CF6",
    icon: "laptop" as const,
    fullTitle: "Delhi e-District Portal — One-Stop Government Services",
    tagline: "All Delhi government services at your fingertips",
    eligibility: [
      "Any Delhi resident with Aadhaar card",
      "Valid mobile number linked to Aadhaar for OTP verification",
      "No income limit — open to all citizens",
      "Available 24/7 online or at CSC centres",
    ],
    benefits: [
      "Caste certificate (SC/ST/OBC) in 7 working days",
      "Income certificate for scholarships and welfare schemes",
      "Domicile certificate for educational admissions",
      "Survival and character certificates",
      "Marriage registration certificate online",
      "Digitally signed — accepted across all government offices",
    ],
    howToApply: "Register at edistrict.delhigovt.nic.in using Aadhaar and mobile OTP. Select the required service, fill the form, pay fee online (₹20–50), and download the certificate after approval.",
    helpline: "011-23935730",
    website: "edistrict.delhigovt.nic.in",
  },
];

function PulsingDot({ color }: { color: string }) {
  const scale = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.loop(Animated.sequence([
      Animated.timing(scale, { toValue: 1.6, duration: 700, useNativeDriver: false }),
      Animated.timing(scale, { toValue: 1, duration: 700, useNativeDriver: false }),
    ])).start();
  }, []);
  return <Animated.View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: color, transform: [{ scale }] }} />;
}

function HealthBar({ pct, color }: { pct: number; color: string }) {
  const anim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(anim, { toValue: pct, duration: 1200, delay: 300, useNativeDriver: false }).start();
  }, [pct]);
  return (
    <View style={{ height: 8, backgroundColor: "#F3F4F6", borderRadius: 4, overflow: "hidden" }}>
      <Animated.View style={{
        height: 8, borderRadius: 4, backgroundColor: color,
        width: anim.interpolate({ inputRange: [0, 100], outputRange: ["0%", "100%"] }) as any,
      }} />
    </View>
  );
}

function SchemeModal({ scheme, onClose }: { scheme: typeof SCHEMES_DATA[0] | null; onClose: () => void }) {
  if (!scheme) return null;
  return (
    <Modal visible animationType="slide" transparent>
      <View style={ms.overlay}>
        <Pressable style={ms.backdrop} onPress={onClose} />
        <View style={ms.card}>
          <View style={ms.handle} />
          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Header */}
            <LinearGradient colors={[scheme.color + "22", scheme.color + "08"]} style={ms.header}>
              <View style={[ms.headerIcon, { backgroundColor: scheme.color + "18", borderColor: scheme.color + "30" }]}>
                <Ionicons name={scheme.icon} size={28} color={scheme.color} />
              </View>
              <View style={{ flex: 1 }}>
                <View style={[ms.tagPill, { backgroundColor: scheme.color + "18" }]}>
                  <Text style={[ms.tagText, { color: scheme.color }]}>{scheme.tag}</Text>
                </View>
                <Text style={ms.modalTitle}>{scheme.fullTitle}</Text>
                <Text style={ms.modalTagline}>{scheme.tagline}</Text>
              </View>
            </LinearGradient>

            {/* Eligibility */}
            <View style={ms.section}>
              <View style={ms.sectionHeader}>
                <View style={[ms.sectionIcon, { backgroundColor: "#FFF8E7" }]}>
                  <Ionicons name="person-circle" size={16} color="#F59E0B" />
                </View>
                <Text style={ms.sectionTitle}>Who Can Apply?</Text>
              </View>
              {scheme.eligibility.map((e, i) => (
                <View key={i} style={ms.bullet}>
                  <View style={[ms.bulletDot, { backgroundColor: scheme.color }]} />
                  <Text style={ms.bulletText}>{e}</Text>
                </View>
              ))}
            </View>

            {/* Benefits */}
            <View style={ms.section}>
              <View style={ms.sectionHeader}>
                <View style={[ms.sectionIcon, { backgroundColor: "#F0FFF4" }]}>
                  <Ionicons name="gift" size={16} color="#00A651" />
                </View>
                <Text style={ms.sectionTitle}>Key Benefits</Text>
              </View>
              {scheme.benefits.map((b, i) => (
                <View key={i} style={ms.bullet}>
                  <Ionicons name="checkmark-circle" size={16} color="#00A651" />
                  <Text style={ms.bulletText}>{b}</Text>
                </View>
              ))}
            </View>

            {/* How to Apply */}
            <View style={ms.section}>
              <View style={ms.sectionHeader}>
                <View style={[ms.sectionIcon, { backgroundColor: "#EFF6FF" }]}>
                  <Ionicons name="document-text" size={16} color="#3B82F6" />
                </View>
                <Text style={ms.sectionTitle}>How to Apply</Text>
              </View>
              <View style={[ms.howBox, { borderLeftColor: scheme.color }]}>
                <Text style={ms.howText}>{scheme.howToApply}</Text>
              </View>
            </View>

            {/* Contact */}
            <View style={ms.contactRow}>
              <Pressable style={[ms.contactBtn, { backgroundColor: scheme.color + "12", borderColor: scheme.color + "30" }]}
                onPress={() => Linking.openURL(`tel:${scheme.helpline}`)}>
                <Ionicons name="call" size={18} color={scheme.color} />
                <Text style={[ms.contactBtnText, { color: scheme.color }]}>Helpline: {scheme.helpline}</Text>
              </Pressable>
              <Pressable style={[ms.contactBtn, { backgroundColor: "#F9FAFB", borderColor: "#E5E7EB" }]}
                onPress={() => Linking.openURL(`https://${scheme.website}`)}>
                <Ionicons name="globe" size={18} color="#6B7280" />
                <Text style={[ms.contactBtnText, { color: "#6B7280" }]}>Website</Text>
              </Pressable>
            </View>

            <Pressable style={ms.closeBtn} onPress={onClose}>
              <Text style={ms.closeBtnText}>Close</Text>
            </Pressable>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

function NoticeModal({ notice, onClose }: { notice: any; onClose: () => void }) {
  if (!notice) return null;
  const date = new Date(notice.createdAt || Date.now());
  const dateStr = date.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
  return (
    <Modal visible animationType="slide" transparent>
      <View style={ms.overlay}>
        <Pressable style={ms.backdrop} onPress={onClose} />
        <View style={ms.card}>
          <View style={ms.handle} />
          <View style={[ms.header, { flexDirection: "column", gap: 10 }]}>
            {notice.priority === "urgent" && (
              <View style={nm.urgentBanner}>
                <Ionicons name="warning" size={14} color="#DC2626" />
                <Text style={nm.urgentText}>URGENT NOTICE</Text>
              </View>
            )}
            <View style={[ms.tagPill, { backgroundColor: "#FFF8E7" }]}>
              <Text style={[ms.tagText, { color: "#FF9933" }]}>{notice.department?.toUpperCase() || "GOVERNMENT"}</Text>
            </View>
            <Text style={ms.modalTitle}>{notice.title}</Text>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              <Ionicons name="calendar-outline" size={13} color="#9CA3AF" />
              <Text style={ms.modalTagline}>{dateStr}</Text>
            </View>
          </View>
          <View style={ms.section}>
            <Text style={nm.body}>{notice.content || notice.body || "This is an official government notice from the Delhi Administration. Please read carefully and take any required action promptly. For queries, contact your nearest government office or helpline."}</Text>
          </View>
          {notice.actionLabel && (
            <Pressable style={[ms.contactBtn, { backgroundColor: "#FF9933", borderColor: "#FF9933", margin: 16 }]}>
              <Ionicons name="arrow-forward" size={16} color="#fff" />
              <Text style={[ms.contactBtnText, { color: "#fff" }]}>{notice.actionLabel}</Text>
            </Pressable>
          )}
          <Pressable style={ms.closeBtn} onPress={onClose}>
            <Text style={ms.closeBtnText}>Close</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const { complaints, sosAlerts, wards, isLoading, refresh, getStats, announcements, emergencyAlert, clearEmergency } = useApp();
  const { user } = useAuth();

  const headerAnim = useRef(new Animated.Value(0)).current;
  const cardsAnim = useRef(new Animated.Value(0)).current;

  const [selectedScheme, setSelectedScheme] = useState<typeof SCHEMES_DATA[0] | null>(null);
  const [selectedNotice, setSelectedNotice] = useState<any>(null);

  const stats = getStats();
  const activeAlerts = sosAlerts.filter(s => s.status === "active");
  const todayComplaints = complaints.filter(c => {
    const d = new Date(c.submittedAt);
    const now = new Date();
    return d.toDateString() === now.toDateString();
  });
  const avgHealth = stats.avgHealth;
  const healthColor = avgHealth >= 70 ? "#00A651" : avgHealth >= 50 ? "#F59E0B" : "#EF4444";
  const total = complaints.length || 1;

  const catBreakdown = Object.entries(CATEGORY_META).map(([key, meta]) => ({
    key, ...meta,
    count: complaints.filter(c => c.category === key).length,
    pct: Math.round((complaints.filter(c => c.category === key).length / total) * 100),
  })).sort((a, b) => b.count - a.count).slice(0, 5);

  useEffect(() => {
    Animated.stagger(100, [
      Animated.timing(headerAnim, { toValue: 1, duration: 600, useNativeDriver: false }),
      Animated.timing(cardsAnim, { toValue: 1, duration: 700, delay: 100, useNativeDriver: false }),
    ]).start();
  }, []);

  const greet = () => {
    const h = new Date().getHours();
    if (h < 12) return "Good Morning";
    if (h < 17) return "Good Afternoon";
    return "Good Evening";
  };

  const initials = user?.name?.split(" ").map((n: string) => n[0]).join("").slice(0, 2).toUpperCase() || "?";

  return (
    <View style={styles.container}>
      <SchemeModal scheme={selectedScheme} onClose={() => setSelectedScheme(null)} />
      <NoticeModal notice={selectedNotice} onClose={() => setSelectedNotice(null)} />

      <ScrollView
        refreshControl={<RefreshControl refreshing={isLoading} onRefresh={refresh} tintColor="#FF9933" colors={["#FF9933"]} />}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: Platform.OS === "web" ? 34 : insets.bottom + 100 }}
      >
        {/* HEADER */}
        <LinearGradient
          colors={["#FF6B00", "#FF9933", "#FFBA5C"]}
          style={[styles.header, { paddingTop: Platform.OS === "web" ? 80 : insets.top + 16 }]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        >
          <View style={styles.headerBgCircle1} />
          <View style={styles.headerBgCircle2} />

          <Animated.View style={{ opacity: headerAnim }}>
            <View style={styles.headerTop}>
              <View>
                <Text style={styles.greeting}>{greet()},</Text>
                <Text style={styles.userName}>{user?.name?.split(" ")[0] || "Citizen"} 👋</Text>
                <View style={styles.livePill}>
                  <PulsingDot color="#fff" />
                  <Text style={styles.liveText}>Live · Delhi Command Center</Text>
                </View>
              </View>
              <View style={styles.headerRight}>
                <NotificationBell />
                <Pressable onPress={() => router.push("/(tabs)/profile")} style={styles.avatarBtn}>
                  <Text style={styles.avatarBtnText}>{initials}</Text>
                </Pressable>
                {user?.role === "admin" && (
                  <Pressable onPress={() => router.push("/admin")} style={styles.adminBtn}>
                    <Ionicons name="shield-checkmark" size={18} color="#FF9933" />
                  </Pressable>
                )}
              </View>
            </View>

            <View style={styles.tricolor}>
              <View style={{ flex: 1, backgroundColor: "#fff", opacity: 0.9 }} />
              <View style={{ flex: 1, backgroundColor: "rgba(255,255,255,0.4)" }} />
              <View style={{ flex: 1, backgroundColor: "#138808" }} />
            </View>

            <View style={styles.healthCard}>
              <View style={styles.healthCardLeft}>
                <Text style={styles.healthCardLabel}>City Health Score</Text>
                <Text style={styles.healthCardSub}>Delhi · {wards.length} Wards Monitored</Text>
                <HealthBar pct={avgHealth} color={healthColor} />
              </View>
              <View style={[styles.healthScoreBubble, { borderColor: healthColor + "44" }]}>
                <Text style={[styles.healthScore, { color: healthColor }]}>{avgHealth}</Text>
                <Text style={styles.healthScoreOf}>/100</Text>
              </View>
            </View>
          </Animated.View>
        </LinearGradient>

        {/* SOS ALERT BANNER */}
        {activeAlerts.length > 0 && (
          <Pressable onPress={() => router.push("/(tabs)/sos")} style={styles.sosBanner}>
            <LinearGradient colors={["#7F1D1D", "#DC2626"]} style={styles.sosBannerInner}>
              <View style={styles.sosIconWrap}>
                <Ionicons name="warning" size={18} color="#fff" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.sosBannerTitle}>{activeAlerts.length} ACTIVE SOS ALERT{activeAlerts.length > 1 ? "S" : ""}</Text>
                <Text style={styles.sosBannerSub}>{activeAlerts[0]?.location} · Tap to respond</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.7)" />
            </LinearGradient>
          </Pressable>
        )}

        {/* ADMIN EMERGENCY BROADCAST BANNER */}
        {!!emergencyAlert && (
          <Pressable onPress={clearEmergency} style={{ marginHorizontal: 16, marginTop: 14, borderRadius: 14, overflow: "hidden" }}>
            <LinearGradient colors={["#4C1D95", "#7C3AED", "#6D28D9"]} style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14, gap: 12 }}>
              <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" }}>
                <Text style={{ fontSize: 20 }}>🚨</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ color: "#fff", fontSize: 13, fontFamily: "Inter_700Bold", letterSpacing: 0.5 }}>
                  ⚡ CITY-WIDE EMERGENCY ALERT
                </Text>
                <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 11, fontFamily: "Inter_400Regular", marginTop: 2 }} numberOfLines={2}>
                  {emergencyAlert.message}
                </Text>
              </View>
              <Ionicons name="close-circle" size={20} color="rgba(255,255,255,0.7)" />
            </LinearGradient>
          </Pressable>
        )}

        {/* MY ACTIVITY SECTION */}
        <Animated.View style={{ opacity: cardsAnim, marginHorizontal: 16, marginTop: 14 }}>
          <View style={styles.activityCard}>
            <View style={styles.activityHeader}>
              <View style={styles.activityTitleRow}>
                <View style={[styles.kpiIconWrap, { backgroundColor: "#FFF0E6" }]}>
                  <Ionicons name="person-circle" size={16} color="#FF9933" />
                </View>
                <Text style={styles.activityTitle}>My Civic Activity</Text>
              </View>
              <Pressable onPress={() => router.push("/(tabs)/complaints")} style={styles.activitySeeAll}>
                <Text style={styles.activitySeeAllText}>See All</Text>
                <Ionicons name="chevron-forward" size={12} color="#FF9933" />
              </Pressable>
            </View>
            <View style={styles.activityStats}>
              {(() => {
                const myC = complaints.filter(c => c.submittedByPhone === user?.phone);
                const myR = myC.filter(c => c.status === "resolved");
                const myP = myC.filter(c => c.status === "pending" || c.status === "in_progress");
                return [
                  { label: "Filed",    value: myC.length,  color: "#FF9933", icon: "document-text" as const, bg: "#FFF8E7" },
                  { label: "Pending",  value: myP.length,  color: "#F59E0B", icon: "time" as const,          bg: "#FFFBEB" },
                  { label: "Resolved", value: myR.length,  color: "#00A651", icon: "checkmark-circle" as const, bg: "#F0FFF4" },
                  { label: "City SOS", value: activeAlerts.length, color: "#EF4444", icon: "warning" as const, bg: "#FEF2F2" },
                ];
              })().map((item, i) => (
                <View key={i} style={[styles.activityStatItem, { backgroundColor: item.bg, borderColor: item.color + "28" }]}>
                  <View style={[styles.kpiIconWrap, { backgroundColor: item.color + "18" }]}>
                    <Ionicons name={item.icon} size={16} color={item.color} />
                  </View>
                  <Text style={[styles.activityStatNum, { color: item.color }]}>{item.value}</Text>
                  <Text style={styles.activityStatLabel}>{item.label}</Text>
                </View>
              ))}
            </View>
            {/* Motivational row */}
            <View style={styles.motivRow}>
              <Text style={{ fontSize: 18 }}>🌟</Text>
              <Text style={styles.motivText}>
                {user?.level && user.level >= 3
                  ? `Level ${user.level} Civic Advocate — keep making Delhi better!`
                  : "File your first complaint to start earning civic points!"}
              </Text>
            </View>
          </View>
        </Animated.View>

        {/* QUICK NAV */}
        <View style={styles.quickNav}>
          <Text style={styles.sectionLabel}>QUICK ACCESS</Text>
          <View style={styles.quickGrid}>
            {[
              { icon: "chatbubbles" as const, label: "AI Chat",   color: "#FF9933", bg: "#FFF8E7", nav: "/(tabs)/ai" },
              { icon: "map" as const,         label: "Live Map",  color: "#3B82F6", bg: "#EFF6FF", nav: "/(tabs)/map" },
              { icon: "receipt-outline" as const, label: "Pay Bills", color: "#8B5CF6", bg: "#F5F3FF", nav: "/(tabs)/bills" },
              { icon: "trophy" as const,      label: "My Profile", color: "#00A651", bg: "#F0FFF4", nav: "/(tabs)/profile" },
            ].map(item => (
              <Pressable key={item.label} onPress={() => router.push(item.nav as any)} style={[styles.quickCard, { backgroundColor: item.bg, borderColor: item.color + "30" }]}>
                <View style={[styles.quickCardIcon, { backgroundColor: item.color + "18" }]}>
                  <Ionicons name={item.icon} size={22} color={item.color} />
                </View>
                <Text style={[styles.quickCardLabel, { color: item.color }]}>{item.label}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* AI BANNER */}
        <Pressable onPress={() => router.push("/(tabs)/ai")} style={styles.aiBanner}>
          <LinearGradient
            colors={["#FF6B00", "#FF9933", "#FFBA5C"]}
            style={styles.aiBannerGrad}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
          >
            <View style={styles.aiBannerLeft}>
              <View style={styles.aiBannerIcon}>
                <Text style={{ fontSize: 28 }}>🤖</Text>
              </View>
              <View>
                <Text style={styles.aiBannerTitle}>SANKALP AI Assistant</Text>
                <Text style={styles.aiBannerSub}>Ask anything about Delhi civic services</Text>
              </View>
            </View>
            <View style={styles.aiBannerStats}>
              <Text style={styles.aiBannerStatNum}>{Math.round(complaints.reduce((s, c) => s + c.aiScore, 0) / Math.max(complaints.length, 1))}%</Text>
              <Text style={styles.aiBannerStatLabel}>AI Score</Text>
            </View>
            <View style={styles.aiBannerArrow}>
              <Ionicons name="arrow-forward" size={16} color="#fff" />
            </View>
          </LinearGradient>
        </Pressable>

        {/* DELHI AQI LIVE */}
        <View style={styles.aqiCard}>
          <LinearGradient colors={["#7F1D1D", "#991B1B", "#B91C1C"]} style={styles.aqiGrad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
            <View style={styles.aqiLeft}>
              <View style={styles.aqiIconWrap}><Text style={{ fontSize: 22 }}>🌫️</Text></View>
              <View>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                  <Text style={styles.aqiTitle}>Delhi AQI</Text>
                  <View style={styles.aqiLivePill}>
                    <View style={{ width: 5, height: 5, borderRadius: 2.5, backgroundColor: "#4ADE80" }} />
                    <Text style={styles.aqiLiveText}>LIVE</Text>
                  </View>
                </View>
                <Text style={styles.aqiSub}>Air Quality Index · Hazardous</Text>
                <Text style={styles.aqiAdvice}>🚨 Wear N95 mask outdoors</Text>
              </View>
            </View>
            <View style={styles.aqiRight}>
              <Text style={styles.aqiNum}>347</Text>
              <Text style={styles.aqiCategory}>HAZARDOUS</Text>
              <View style={styles.aqiBar}><View style={[styles.aqiBarFill, { width: "75%" }]} /></View>
            </View>
          </LinearGradient>
          <View style={styles.aqiBreakdown}>
            {[
              { label: "PM2.5", val: "198", color: "#EF4444" },
              { label: "PM10",  val: "247", color: "#F59E0B" },
              { label: "NO₂",   val: "62",  color: "#8B5CF6" },
              { label: "CO",    val: "8.4", color: "#06B6D4" },
            ].map(m => (
              <View key={m.label} style={styles.aqiMetric}>
                <Text style={[styles.aqiMetricVal, { color: m.color }]}>{m.val}</Text>
                <Text style={styles.aqiMetricLabel}>{m.label}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* EMERGENCY CONTACTS */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleWrap}>
              <View style={[styles.kpiIconWrap, { backgroundColor: "#FEF2F2" }]}>
                <Ionicons name="call" size={14} color="#EF4444" />
              </View>
              <Text style={styles.sectionTitle}>Emergency Helplines</Text>
            </View>
            <View style={styles.livePill}>
              <PulsingDot color="#EF4444" />
              <Text style={[styles.liveText, { color: "#EF4444" }]}>24/7</Text>
            </View>
          </View>
          <View style={styles.emergGrid}>
            {[
              { num: "100",  label: "Police",        icon: "shield",    color: "#1A237E", bg: "#E8EAFF" },
              { num: "108",  label: "Ambulance",      icon: "heart",     color: "#EF4444", bg: "#FEF2F2" },
              { num: "1090", label: "Women Safety",   icon: "woman",     color: "#EC4899", bg: "#FDF2F8" },
              { num: "101",  label: "Fire Brigade",   icon: "flame",     color: "#F59E0B", bg: "#FFFBEB" },
              { num: "1095", label: "Traffic Police", icon: "car",       color: "#06B6D4", bg: "#F0FDFF" },
              { num: "1098", label: "Child Helpline", icon: "happy",     color: "#00A651", bg: "#F0FFF4" },
            ].map(e => (
              <Pressable key={e.num}
                onPress={() => Linking.openURL(`tel:${e.num}`)}
                style={[styles.emergCard, { backgroundColor: e.bg, borderColor: e.color + "30" }]}>
                <View style={[styles.emergIconWrap, { backgroundColor: e.color + "18" }]}>
                  <Ionicons name={e.icon as any} size={16} color={e.color} />
                </View>
                <Text style={[styles.emergNum, { color: e.color }]}>{e.num}</Text>
                <Text style={styles.emergLabel}>{e.label}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* GOVERNMENT SCHEMES */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleWrap}>
              <Ionicons name="document-text" size={16} color="#FF9933" />
              <Text style={styles.sectionTitle}>Delhi Govt Schemes</Text>
            </View>
            <Pressable><Text style={styles.seeAll}>View All →</Text></Pressable>
          </View>
          {SCHEMES_DATA.map((s, idx) => (
            <Pressable key={s.key} onPress={() => setSelectedScheme(s)}
              style={[styles.schemeRow, { borderTopWidth: idx === 0 ? 0 : 1 }]}>
              <View style={[styles.schemeIcon, { backgroundColor: s.color + "15" }]}>
                <Ionicons name={s.icon} size={18} color={s.color} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.schemeTitle}>{s.title}</Text>
                <Text style={styles.schemeSub}>{s.sub}</Text>
              </View>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                <View style={[styles.schemeTag, { backgroundColor: s.color + "15" }]}>
                  <Text style={[styles.schemeTagText, { color: s.color }]}>{s.tag}</Text>
                </View>
                <Ionicons name="chevron-forward" size={14} color="#9CA3AF" />
              </View>
            </Pressable>
          ))}
        </View>

        {/* GOVERNMENT NOTICES */}
        {announcements.length > 0 && (
          <View style={[styles.sectionCard, { borderColor: "#FFD07733" }]}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionTitleWrap}>
                <View style={styles.megaphoneIcon}>
                  <Ionicons name="megaphone" size={14} color="#FF9933" />
                </View>
                <Text style={styles.sectionTitle}>Government Notices</Text>
              </View>
            </View>
            <View style={styles.tricolorThin}>
              <View style={{ flex: 1, backgroundColor: "#FF9933" }} />
              <View style={{ flex: 1, backgroundColor: "#E5E7EB" }} />
              <View style={{ flex: 1, backgroundColor: "#138808" }} />
            </View>
            {announcements.slice(0, 3).map(ann => (
              <Pressable key={ann.id} onPress={() => setSelectedNotice(ann)} style={[styles.annRow, { borderRadius: 8 }]}>
                <View style={styles.annDot} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.annTitle} numberOfLines={1}>{ann.title}</Text>
                  <Text style={styles.annDept}>{ann.department}</Text>
                </View>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                  {ann.priority === "urgent" && (
                    <View style={styles.urgentBadge}><Text style={styles.urgentText}>URGENT</Text></View>
                  )}
                  <Ionicons name="chevron-forward" size={14} color="#9CA3AF" />
                </View>
              </Pressable>
            ))}
          </View>
        )}

        {/* CATEGORY BREAKDOWN */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleWrap}>
              <Ionicons name="pie-chart" size={16} color="#3B82F6" />
              <Text style={styles.sectionTitle}>Issue Breakdown</Text>
            </View>
            <Pressable onPress={() => router.push("/(tabs)/analytics")}>
              <Text style={styles.seeAll}>View Analytics →</Text>
            </Pressable>
          </View>
          {catBreakdown.map(cat => (
            <View key={cat.key} style={styles.catRow}>
              <View style={[styles.catIconWrap, { backgroundColor: cat.bg }]}>
                <Ionicons name={cat.icon} size={13} color={cat.color} />
              </View>
              <Text style={styles.catLabel}>{cat.label}</Text>
              <View style={{ flex: 1, height: 6, backgroundColor: "#F3F4F6", borderRadius: 3, overflow: "hidden" }}>
                <View style={{ height: 6, borderRadius: 3, backgroundColor: cat.color, width: `${cat.pct}%` }} />
              </View>
              <Text style={[styles.catPct, { color: cat.color }]}>{cat.pct}%</Text>
            </View>
          ))}
        </View>

        {/* RECENT REPORTS */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleWrap}>
              <Ionicons name="list" size={16} color="#00A651" />
              <Text style={styles.sectionTitle}>Recent Reports</Text>
            </View>
            <Pressable onPress={() => router.push("/(tabs)/complaints")}>
              <Text style={styles.seeAll}>See All →</Text>
            </Pressable>
          </View>
          {complaints.slice(0, 5).map(c => {
            const meta = CATEGORY_META[c.category] || CATEGORY_META.other;
            const statusMeta = STATUS_META[c.status] || STATUS_META.closed;
            return (
              <Pressable key={c.id} onPress={() => router.push("/(tabs)/complaints")} style={styles.complaintRow}>
                <View style={[styles.complaintIcon, { backgroundColor: meta.bg }]}>
                  <Ionicons name={meta.icon} size={18} color={meta.color} />
                </View>
                <View style={{ flex: 1 }}>
                  <View style={styles.complaintTopRow}>
                    <Text style={styles.complaintId}>{c.ticketId}</Text>
                    <View style={[styles.priorityPill, { backgroundColor: c.priority === "P1" ? "#FEF2F2" : c.priority === "P2" ? "#FFFBEB" : "#F0FFF4" }]}>
                      <Text style={[styles.priorityText, { color: c.priority === "P1" ? "#EF4444" : c.priority === "P2" ? "#F59E0B" : "#00A651" }]}>{c.priority}</Text>
                    </View>
                  </View>
                  <Text style={styles.complaintDesc} numberOfLines={1}>{c.description}</Text>
                  <View style={styles.complaintLocation}>
                    <Ionicons name="location-outline" size={10} color="#9CA3AF" />
                    <Text style={styles.complaintLocationText} numberOfLines={1}>{c.location}</Text>
                  </View>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: statusMeta.bg }]}>
                  <Text style={[styles.statusText, { color: statusMeta.color }]}>{statusMeta.label}</Text>
                </View>
              </Pressable>
            );
          })}
        </View>

        {/* WARD HEALTH */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleWrap}>
              <Ionicons name="map" size={16} color="#8B5CF6" />
              <Text style={styles.sectionTitle}>Ward Health Overview</Text>
            </View>
          </View>
          <View style={styles.wardGrid}>
            {wards.slice(0, 12).map(ward => {
              const c = ward.healthScore >= 70 ? "#00A651" : ward.healthScore >= 50 ? "#F59E0B" : "#EF4444";
              return (
                <Pressable key={ward.id} onPress={() => router.push("/(tabs)/analytics")} style={[styles.wardChip, { borderColor: c + "44", backgroundColor: c + "10" }]}>
                  <View style={[styles.wardDot, { backgroundColor: c }]} />
                  <Text style={[styles.wardName, { color: c }]} numberOfLines={1}>{ward.name.split(" ")[0]}</Text>
                  <Text style={styles.wardScore}>{ward.healthScore}</Text>
                </Pressable>
              );
            })}
          </View>
        </View>

      </ScrollView>
    </View>
  );
}

const ms = StyleSheet.create({
  overlay: { flex: 1, justifyContent: "flex-end" },
  backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(0,0,0,0.5)" },
  card: {
    backgroundColor: "#fff", borderTopLeftRadius: 28, borderTopRightRadius: 28,
    maxHeight: "90%", shadowColor: "#000", shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.15, shadowRadius: 20, elevation: 20,
  },
  handle: { width: 40, height: 4, backgroundColor: "#E5E7EB", borderRadius: 2, alignSelf: "center", marginTop: 12, marginBottom: 4 },
  header: { padding: 20, flexDirection: "row", gap: 14, alignItems: "flex-start" },
  headerIcon: { width: 56, height: 56, borderRadius: 16, alignItems: "center", justifyContent: "center", borderWidth: 1 },
  tagPill: { alignSelf: "flex-start", borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4, marginBottom: 6 },
  tagText: { fontSize: 10, fontFamily: "Inter_700Bold", letterSpacing: 1 },
  modalTitle: { color: "#111827", fontSize: 18, fontFamily: "Inter_700Bold", lineHeight: 24, marginBottom: 4 },
  modalTagline: { color: "#6B7280", fontSize: 12, fontFamily: "Inter_400Regular" },
  section: { paddingHorizontal: 20, paddingVertical: 12, borderTopWidth: 1, borderTopColor: "#F3F4F6" },
  sectionHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10 },
  sectionIcon: { width: 30, height: 30, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  sectionTitle: { color: "#111827", fontSize: 14, fontFamily: "Inter_600SemiBold" },
  bullet: { flexDirection: "row", alignItems: "flex-start", gap: 10, marginBottom: 8 },
  bulletDot: { width: 7, height: 7, borderRadius: 3.5, marginTop: 6 },
  bulletText: { flex: 1, color: "#374151", fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 20 },
  howBox: { borderLeftWidth: 3, paddingLeft: 14, backgroundColor: "#F9FAFB", borderRadius: 4, padding: 12 },
  howText: { color: "#374151", fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 20 },
  contactRow: { flexDirection: "row", gap: 10, paddingHorizontal: 20, paddingVertical: 12 },
  contactBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, borderRadius: 12, paddingVertical: 14, borderWidth: 1 },
  contactBtnText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  closeBtn: { marginHorizontal: 20, marginBottom: 28, marginTop: 4, backgroundColor: "#F3F4F6", borderRadius: 14, paddingVertical: 14, alignItems: "center" },
  closeBtnText: { color: "#6B7280", fontSize: 15, fontFamily: "Inter_600SemiBold" },
});

const nm = StyleSheet.create({
  urgentBanner: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#FEF2F2", borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6, alignSelf: "flex-start" },
  urgentText: { color: "#DC2626", fontSize: 11, fontFamily: "Inter_700Bold", letterSpacing: 0.5 },
  body: { color: "#374151", fontSize: 14, fontFamily: "Inter_400Regular", lineHeight: 22 },
});

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F8F9FA" },

  header: { paddingHorizontal: 20, paddingBottom: 24, overflow: "hidden" },
  headerBgCircle1: { position: "absolute", width: 200, height: 200, borderRadius: 100, backgroundColor: "rgba(255,255,255,0.08)", top: -60, right: -40 },
  headerBgCircle2: { position: "absolute", width: 120, height: 120, borderRadius: 60, backgroundColor: "rgba(255,255,255,0.06)", bottom: 0, left: 30 },
  headerTop: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 12 },
  greeting: { color: "rgba(255,255,255,0.85)", fontSize: 13, fontFamily: "Inter_400Regular" },
  userName: { color: "#fff", fontSize: 26, fontFamily: "Inter_700Bold", marginTop: 2 },
  livePill: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 6 },
  liveText: { color: "rgba(255,255,255,0.9)", fontSize: 11, fontFamily: "Inter_500Medium" },
  headerRight: { flexDirection: "row", gap: 8, alignItems: "center" },
  avatarBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.25)", borderWidth: 2, borderColor: "rgba(255,255,255,0.6)", alignItems: "center", justifyContent: "center" },
  avatarBtnText: { color: "#fff", fontSize: 13, fontFamily: "Inter_700Bold" },
  adminBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.2)", borderWidth: 1, borderColor: "rgba(255,255,255,0.3)", alignItems: "center", justifyContent: "center" },
  tricolor: { height: 3, flexDirection: "row", borderRadius: 1.5, overflow: "hidden", marginBottom: 14 },
  healthCard: { backgroundColor: "rgba(255,255,255,0.18)", borderRadius: 16, padding: 16, flexDirection: "row", alignItems: "center", gap: 12, borderWidth: 1, borderColor: "rgba(255,255,255,0.25)" },
  healthCardLeft: { flex: 1, gap: 6 },
  healthCardLabel: { color: "#fff", fontSize: 14, fontFamily: "Inter_600SemiBold" },
  healthCardSub: { color: "rgba(255,255,255,0.75)", fontSize: 11, fontFamily: "Inter_400Regular" },
  healthScoreBubble: { width: 72, height: 72, borderRadius: 36, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center", borderWidth: 2 },
  healthScore: { fontSize: 26, fontFamily: "Inter_700Bold" },
  healthScoreOf: { color: "rgba(255,255,255,0.7)", fontSize: 10, fontFamily: "Inter_400Regular", marginTop: -2 },

  sosBanner: { marginHorizontal: 16, marginTop: 14, borderRadius: 14, overflow: "hidden" },
  sosBannerInner: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, gap: 10 },
  sosIconWrap: { width: 34, height: 34, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" },
  sosBannerTitle: { color: "#fff", fontSize: 13, fontFamily: "Inter_700Bold" },
  sosBannerSub: { color: "rgba(255,255,255,0.75)", fontSize: 11, fontFamily: "Inter_400Regular", marginTop: 2 },

  kpiIconWrap: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },

  activityCard: { backgroundColor: "#fff", borderRadius: 18, padding: 16, borderWidth: 1, borderColor: "#FFE0B2" },
  activityHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 14 },
  activityTitleRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  activityTitle: { color: "#111827", fontSize: 14, fontFamily: "Inter_700Bold" },
  activitySeeAll: { flexDirection: "row", alignItems: "center", gap: 3 },
  activitySeeAllText: { color: "#FF9933", fontSize: 12, fontFamily: "Inter_500Medium" },
  activityStats: { flexDirection: "row", gap: 8, marginBottom: 12 },
  activityStatItem: { flex: 1, borderRadius: 12, padding: 10, alignItems: "center", gap: 5, borderWidth: 1 },
  activityStatNum: { fontSize: 20, fontFamily: "Inter_700Bold" },
  activityStatLabel: { color: "#9CA3AF", fontSize: 9, fontFamily: "Inter_500Medium", textAlign: "center" },
  motivRow: { flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: "#FFFBEB", borderRadius: 12, padding: 12 },
  motivText: { flex: 1, color: "#92400E", fontSize: 12, fontFamily: "Inter_500Medium", lineHeight: 17 },

  quickNav: { paddingHorizontal: 16, marginTop: 14, marginBottom: 4 },
  sectionLabel: { color: "#9CA3AF", fontSize: 10, fontFamily: "Inter_700Bold", letterSpacing: 1.5, marginBottom: 10 },
  quickGrid: { flexDirection: "row", gap: 8 },
  quickCard: { flex: 1, borderRadius: 14, padding: 12, alignItems: "center", gap: 8, borderWidth: 1 },
  quickCardIcon: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  quickCardLabel: { fontSize: 10, fontFamily: "Inter_600SemiBold", textAlign: "center" },

  aiBanner: { marginHorizontal: 16, marginTop: 14, borderRadius: 16, overflow: "hidden" },
  aiBannerGrad: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14, gap: 12 },
  aiBannerLeft: { flex: 1, flexDirection: "row", alignItems: "center", gap: 12 },
  aiBannerIcon: { width: 50, height: 50, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" },
  aiBannerTitle: { color: "#fff", fontSize: 15, fontFamily: "Inter_700Bold" },
  aiBannerSub: { color: "rgba(255,255,255,0.8)", fontSize: 11, fontFamily: "Inter_400Regular", marginTop: 2 },
  aiBannerStats: { alignItems: "center", backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 10, padding: 10 },
  aiBannerStatNum: { color: "#fff", fontSize: 18, fontFamily: "Inter_700Bold" },
  aiBannerStatLabel: { color: "rgba(255,255,255,0.8)", fontSize: 9, fontFamily: "Inter_400Regular" },
  aiBannerArrow: { width: 32, height: 32, borderRadius: 8, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" },

  aqiCard: { marginHorizontal: 16, marginTop: 14, marginBottom: 4, borderRadius: 20, overflow: "hidden", borderWidth: 1, borderColor: "#FCA5A5" },
  aqiGrad: { flexDirection: "row", alignItems: "center", padding: 16, gap: 12 },
  aqiLeft: { flex: 1, flexDirection: "row", alignItems: "center", gap: 12 },
  aqiIconWrap: { width: 48, height: 48, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "rgba(255,255,255,0.2)" },
  aqiTitle: { color: "#fff", fontSize: 16, fontFamily: "Inter_700Bold" },
  aqiLivePill: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 10, paddingHorizontal: 7, paddingVertical: 3 },
  aqiLiveText: { color: "#4ADE80", fontSize: 9, fontFamily: "Inter_700Bold", letterSpacing: 1 },
  aqiSub: { color: "rgba(255,255,255,0.8)", fontSize: 11, fontFamily: "Inter_400Regular", marginTop: 2 },
  aqiAdvice: { color: "#FCA5A5", fontSize: 11, fontFamily: "Inter_500Medium", marginTop: 4 },
  aqiRight: { alignItems: "flex-end" },
  aqiNum: { color: "#fff", fontSize: 36, fontFamily: "Inter_700Bold", lineHeight: 38 },
  aqiCategory: { color: "#FCA5A5", fontSize: 9, fontFamily: "Inter_700Bold", letterSpacing: 1, marginBottom: 4 },
  aqiBar: { width: 80, height: 4, backgroundColor: "rgba(255,255,255,0.2)", borderRadius: 2, overflow: "hidden" },
  aqiBarFill: { height: 4, backgroundColor: "#FCA5A5", borderRadius: 2 },
  aqiBreakdown: { flexDirection: "row", backgroundColor: "#FFF5F5", paddingVertical: 12, paddingHorizontal: 16 },
  aqiMetric: { flex: 1, alignItems: "center" },
  aqiMetricVal: { fontSize: 15, fontFamily: "Inter_700Bold" },
  aqiMetricLabel: { color: "#9CA3AF", fontSize: 9, fontFamily: "Inter_500Medium", marginTop: 2 },

  emergGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  emergCard: { width: "30%", borderRadius: 14, padding: 10, alignItems: "center", borderWidth: 1, gap: 4 },
  emergIconWrap: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  emergNum: { fontSize: 18, fontFamily: "Inter_700Bold" },
  emergLabel: { color: "#6B7280", fontSize: 9, fontFamily: "Inter_500Medium", textAlign: "center" },

  schemeRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 10, borderTopColor: "#F3F4F6" },
  schemeIcon: { width: 42, height: 42, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  schemeTitle: { color: "#111827", fontSize: 13, fontFamily: "Inter_600SemiBold" },
  schemeSub: { color: "#9CA3AF", fontSize: 11, fontFamily: "Inter_400Regular", marginTop: 2 },
  schemeTag: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  schemeTagText: { fontSize: 9, fontFamily: "Inter_700Bold", letterSpacing: 0.5 },

  sectionCard: { marginHorizontal: 16, backgroundColor: "#fff", borderRadius: 16, padding: 14, borderWidth: 1, borderColor: "#E5E7EB", marginTop: 14 },
  sectionHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 },
  sectionTitleWrap: { flexDirection: "row", alignItems: "center", gap: 8, flex: 1 },
  sectionTitle: { color: "#111827", fontSize: 14, fontFamily: "Inter_700Bold" },
  seeAll: { color: "#FF9933", fontSize: 12, fontFamily: "Inter_500Medium" },
  megaphoneIcon: { width: 28, height: 28, borderRadius: 8, backgroundColor: "#FFF8E7", alignItems: "center", justifyContent: "center" },
  tricolorThin: { height: 2, flexDirection: "row", borderRadius: 1, overflow: "hidden", marginBottom: 12 },
  annRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 8, borderTopWidth: 1, borderTopColor: "#F3F4F6" },
  annDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#FF9933" },
  annTitle: { color: "#111827", fontSize: 13, fontFamily: "Inter_600SemiBold" },
  annDept: { color: "#9CA3AF", fontSize: 10, fontFamily: "Inter_400Regular", marginTop: 2 },
  urgentBadge: { backgroundColor: "#FEF2F2", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 },
  urgentText: { color: "#EF4444", fontSize: 9, fontFamily: "Inter_700Bold" },

  catRow: { flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 7, borderTopWidth: 1, borderTopColor: "#F9FAFB" },
  catIconWrap: { width: 28, height: 28, borderRadius: 7, alignItems: "center", justifyContent: "center" },
  catLabel: { color: "#374151", fontSize: 12, fontFamily: "Inter_500Medium", width: 75 },
  catPct: { fontSize: 12, fontFamily: "Inter_700Bold", width: 36, textAlign: "right" },

  complaintRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 10, borderTopWidth: 1, borderTopColor: "#F9FAFB" },
  complaintIcon: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  complaintTopRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 2 },
  complaintId: { color: "#374151", fontSize: 12, fontFamily: "Inter_700Bold", textTransform: "uppercase" },
  priorityPill: { borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 },
  priorityText: { fontSize: 9, fontFamily: "Inter_700Bold" },
  complaintDesc: { color: "#6B7280", fontSize: 12, fontFamily: "Inter_400Regular" },
  complaintLocation: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 3 },
  complaintLocationText: { color: "#9CA3AF", fontSize: 10, fontFamily: "Inter_400Regular" },
  statusBadge: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 5 },
  statusText: { fontSize: 10, fontFamily: "Inter_600SemiBold" },

  wardGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  wardChip: { flexDirection: "row", alignItems: "center", gap: 5, borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6 },
  wardDot: { width: 7, height: 7, borderRadius: 3.5 },
  wardName: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  wardScore: { color: "#9CA3AF", fontSize: 10, fontFamily: "Inter_400Regular" },
});
